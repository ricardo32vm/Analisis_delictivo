# -*- coding: utf-8 -*-
"""
ui/dialog_main.py

Interfaz del plugin Near Repeat CBA.
Tres pestañas:
  1. Datos y parámetros — carga de capa, umbrales, opciones
  2. Resultado Knox     — interpretación estadística y tabla multibanda
  3. Mapa              — control de capas generadas
"""

import os
import traceback

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QPushButton, QLabel, QComboBox, QCheckBox,
    QTextEdit, QProgressBar, QGroupBox, QFormLayout,
    QDoubleSpinBox, QSpinBox, QSizePolicy, QMessageBox,
    QFileDialog, QRadioButton, QButtonGroup, QSlider
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont, QColor
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsMapLayerType,
    QgsWkbTypes, QgsMessageLog, Qgis
)

try:
    import matplotlib
    matplotlib.use("Qt5Agg")
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    import matplotlib.pyplot as plt
    import numpy as np
    MATPLOTLIB_OK = True
except ImportError:
    MATPLOTLIB_OK = False


# ---------------------------------------------------------------------------
class AnalysisWorker(QThread):
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)
    progress = pyqtSignal(str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func   = func
        self.args   = args
        self.kwargs = kwargs

    def run(self):
        try:
            self.finished.emit(self.func(*self.args, **self.kwargs))
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


# ---------------------------------------------------------------------------
class NearRepeatDialog(QDialog):

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface        = iface
        self.gdf          = None
        self.resultado_kr = None   # resultado Knox test simple
        self.resultado_mb = None   # resultado multibanda
        self.capas_gen    = {}
        self.setWindowTitle("Near Repeat CBA — UNVM")
        self.setMinimumSize(780, 620)
        self._build_ui()
        self._refrescar_capas()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)

        hdr = QLabel("Near Repeat CBA  ·  Análisis de victimización cercana y repetida")
        f = QFont(); f.setBold(True); f.setPointSize(11)
        hdr.setFont(f); hdr.setAlignment(Qt.AlignCenter)
        layout.addWidget(hdr)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_parametros(), "1 · Datos y parámetros")
        self.tabs.addTab(self._tab_resultado(),  "2 · Resultado Knox")
        self.tabs.addTab(self._tab_mapa(),       "3 · Capas del mapa")
        layout.addWidget(self.tabs)

        self.status = QLabel("Cargá una capa de puntos y configurá los parámetros.")
        self.status.setStyleSheet("color: gray; font-size: 11px;")
        layout.addWidget(self.status)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.close)
        layout.addWidget(btn_cerrar)

    # ------------------------------------------------------------------
    # TAB 1: Datos y parámetros
    # ------------------------------------------------------------------
    def _tab_parametros(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        # Fuente de datos
        grp_datos = QGroupBox("Fuente de datos")
        form_datos = QFormLayout(grp_datos)

        # Opción A: usar capa del plugin Crime Analyst CBA
        self.radio_capa_qgis = QRadioButton("Usar capa de puntos del proyecto QGIS")
        self.radio_csv       = QRadioButton("Cargar CSV/Excel directamente")
        self.radio_capa_qgis.setChecked(True)
        bg = QButtonGroup(self)
        bg.addButton(self.radio_capa_qgis)
        bg.addButton(self.radio_csv)
        row_radio = QHBoxLayout()
        row_radio.addWidget(self.radio_capa_qgis)
        row_radio.addWidget(self.radio_csv)
        form_datos.addRow("Fuente:", row_radio)

        # Selector de capa QGIS
        self.cmb_capa = QComboBox()
        btn_refresh = QPushButton("↻")
        btn_refresh.setMaximumWidth(30)
        btn_refresh.clicked.connect(self._refrescar_capas)
        row_capa = QHBoxLayout()
        row_capa.addWidget(self.cmb_capa)
        row_capa.addWidget(btn_refresh)
        form_datos.addRow("Capa de puntos:", row_capa)

        # Carga directa CSV
        self.lbl_csv = QLabel("Sin archivo")
        btn_csv = QPushButton("Examinar...")
        btn_csv.clicked.connect(self._cargar_csv)
        row_csv = QHBoxLayout()
        row_csv.addWidget(self.lbl_csv)
        row_csv.addWidget(btn_csv)
        form_datos.addRow("Archivo CSV/Excel:", row_csv)

        # Filtros
        self.cmb_tipo    = QComboBox()
        self.cmb_tipo.addItem("Todos los tipos de delito")
        self.cmb_distrito = QComboBox()
        self.cmb_distrito.addItem("Todos los distritos")
        form_datos.addRow("Tipo de delito:", self.cmb_tipo)
        form_datos.addRow("Distrito:", self.cmb_distrito)

        layout.addWidget(grp_datos)

        # Parámetros Knox test simple
        grp_knox = QGroupBox("Parámetros — Knox test")
        form_knox = QFormLayout(grp_knox)

        self.spin_dist = QDoubleSpinBox()
        self.spin_dist.setRange(50, 5000)
        self.spin_dist.setValue(200)
        self.spin_dist.setSuffix(" metros")
        self.spin_dist.setSingleStep(50)

        self.spin_tiempo = QSpinBox()
        self.spin_tiempo.setRange(1, 180)
        self.spin_tiempo.setValue(14)
        self.spin_tiempo.setSuffix(" días")

        self.spin_sim = QSpinBox()
        self.spin_sim.setRange(99, 9999)
        self.spin_sim.setValue(999)
        self.spin_sim.setSingleStep(100)
        self.spin_sim.setToolTip("99 = rápido, 999 = estándar, 9999 = preciso")

        form_knox.addRow("Umbral espacial:", self.spin_dist)
        form_knox.addRow("Umbral temporal:", self.spin_tiempo)
        form_knox.addRow("Simulaciones Monte Carlo:", self.spin_sim)
        layout.addWidget(grp_knox)

        # Parámetros multibanda
        grp_mb = QGroupBox("Parámetros — Análisis multibanda (matriz Knox)")
        form_mb = QFormLayout(grp_mb)

        self.spin_banda_dist   = QDoubleSpinBox()
        self.spin_banda_dist.setRange(50, 2000)
        self.spin_banda_dist.setValue(200)
        self.spin_banda_dist.setSuffix(" m")
        self.spin_banda_dist.setSingleStep(50)

        self.spin_n_bandas_dist = QSpinBox()
        self.spin_n_bandas_dist.setRange(2, 10)
        self.spin_n_bandas_dist.setValue(5)

        self.spin_banda_tiempo = QSpinBox()
        self.spin_banda_tiempo.setRange(1, 60)
        self.spin_banda_tiempo.setValue(7)
        self.spin_banda_tiempo.setSuffix(" días")

        self.spin_n_bandas_tiempo = QSpinBox()
        self.spin_n_bandas_tiempo.setRange(2, 10)
        self.spin_n_bandas_tiempo.setValue(4)

        row_dist = QHBoxLayout()
        row_dist.addWidget(QLabel("Banda:"))
        row_dist.addWidget(self.spin_banda_dist)
        row_dist.addWidget(QLabel("N° bandas:"))
        row_dist.addWidget(self.spin_n_bandas_dist)

        row_tiempo = QHBoxLayout()
        row_tiempo.addWidget(QLabel("Banda:"))
        row_tiempo.addWidget(self.spin_banda_tiempo)
        row_tiempo.addWidget(QLabel("N° bandas:"))
        row_tiempo.addWidget(self.spin_n_bandas_tiempo)

        form_mb.addRow("Espacial:", row_dist)
        form_mb.addRow("Temporal:", row_tiempo)
        layout.addWidget(grp_mb)

        # Opciones de capas
        grp_capas = QGroupBox("Capas a generar en el mapa")
        capas_layout = QHBoxLayout(grp_capas)
        self.chk_puntos  = QCheckBox("Puntos de riesgo"); self.chk_puntos.setChecked(True)
        self.chk_buffers = QCheckBox("Buffers de zona");  self.chk_buffers.setChecked(True)
        self.chk_lineas  = QCheckBox("Pares NR (líneas)"); self.chk_lineas.setChecked(True)
        self.chk_heatmap = QCheckBox("Heatmap");           self.chk_heatmap.setChecked(True)
        for chk in [self.chk_puntos, self.chk_buffers, self.chk_lineas, self.chk_heatmap]:
            capas_layout.addWidget(chk)
        layout.addWidget(grp_capas)

        # Botones de ejecución
        row_btn = QHBoxLayout()
        btn_run      = QPushButton("Ejecutar Knox test + generar capas")
        btn_run.setStyleSheet("font-weight: bold; padding: 6px;")
        btn_run.clicked.connect(self._run_analisis)

        btn_multibanda = QPushButton("Generar matriz multibanda")
        btn_multibanda.clicked.connect(self._run_multibanda)

        row_btn.addWidget(btn_run)
        row_btn.addWidget(btn_multibanda)
        layout.addLayout(row_btn)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # TAB 2: Resultado Knox
    # ------------------------------------------------------------------
    def _tab_resultado(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        # Texto de resultado Knox simple
        grp_kr = QGroupBox("Knox test — resultado estadístico")
        kr_l = QVBoxLayout(grp_kr)
        self.txt_resultado = QTextEdit()
        self.txt_resultado.setReadOnly(True)
        self.txt_resultado.setFont(QFont("Courier New", 10))
        self.txt_resultado.setMaximumHeight(220)
        self.txt_resultado.setPlaceholderText(
            "El resultado del Knox test aparecerá aquí después de ejecutar el análisis."
        )
        kr_l.addWidget(self.txt_resultado)
        layout.addWidget(grp_kr)

        # Gráfico de distribución simulada
        grp_plot = QGroupBox("Distribución de simulaciones Monte Carlo")
        plot_l = QVBoxLayout(grp_plot)
        if MATPLOTLIB_OK:
            self.fig_dist = Figure(figsize=(7, 3), tight_layout=True)
            self.canvas_dist = FigureCanvas(self.fig_dist)
            self.canvas_dist.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            plot_l.addWidget(self.canvas_dist)
        else:
            plot_l.addWidget(QLabel("matplotlib no instalado."))
        layout.addWidget(grp_plot)

        # Tabla multibanda
        grp_mb = QGroupBox("Matriz multibanda — p-valores (Knox ratios entre paréntesis)")
        mb_l = QVBoxLayout(grp_mb)
        self.txt_multibanda = QTextEdit()
        self.txt_multibanda.setReadOnly(True)
        self.txt_multibanda.setFont(QFont("Courier New", 9))
        self.txt_multibanda.setMaximumHeight(180)
        self.txt_multibanda.setPlaceholderText(
            "La matriz multibanda aparecerá aquí después de ejecutar el análisis multibanda.\n"
            "p < 0.05 indica patrón near repeat significativo en esa celda."
        )
        mb_l.addWidget(self.txt_multibanda)
        layout.addWidget(grp_mb)

        return w

    # ------------------------------------------------------------------
    # TAB 3: Capas del mapa
    # ------------------------------------------------------------------
    def _tab_mapa(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp = QGroupBox("Capas generadas")
        grp_l = QVBoxLayout(grp)

        self.lbl_capas_info = QLabel(
            "Las capas se generan automáticamente al ejecutar el análisis.\n\n"
            "Capas generadas:\n"
            "  🔴 NR — Puntos de riesgo: eventos coloreados por nivel NR\n"
            "  🟠 NR — Buffers de riesgo: zona de influencia near repeat\n"
            "  🟡 NR — Pares near repeat: líneas entre eventos relacionados\n"
            "  🌡  NR — Heatmap: concentración espacial de riesgo NR\n\n"
            "Leyenda de colores (puntos y buffers):\n"
            "  ⬜ Gris   = Sin riesgo NR detectado\n"
            "  🟡 Amarillo = Riesgo bajo (1 par near repeat)\n"
            "  🟠 Naranja  = Riesgo medio (2-3 pares)\n"
            "  🔴 Rojo     = Riesgo alto (4+ pares)"
        )
        self.lbl_capas_info.setStyleSheet("font-size: 12px; line-height: 1.5;")
        grp_l.addWidget(self.lbl_capas_info)
        layout.addWidget(grp)

        grp2 = QGroupBox("Resumen de riesgo")
        grp2_l = QVBoxLayout(grp2)
        self.txt_resumen_riesgo = QTextEdit()
        self.txt_resumen_riesgo.setReadOnly(True)
        self.txt_resumen_riesgo.setMaximumHeight(120)
        self.txt_resumen_riesgo.setPlaceholderText("El resumen aparecerá después del análisis.")
        grp2_l.addWidget(self.txt_resumen_riesgo)
        layout.addWidget(grp2)

        btn_zoom = QPushButton("Zoom a la extensión de las capas NR")
        btn_zoom.clicked.connect(self._zoom_capas)
        layout.addWidget(btn_zoom)

        btn_exportar = QPushButton("Exportar capas a GeoPackage (.gpkg)...")
        btn_exportar.clicked.connect(self._exportar_capas)
        layout.addWidget(btn_exportar)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Acciones
    # ------------------------------------------------------------------
    def _refrescar_capas(self):
        """Pobla el combo con las capas de puntos del proyecto QGIS."""
        self.cmb_capa.clear()
        self.cmb_capa.addItem("— Seleccionar capa —")
        for layer in QgsProject.instance().mapLayers().values():
            if (layer.type() == QgsMapLayerType.VectorLayer and
                    layer.geometryType() == QgsWkbTypes.PointGeometry):
                self.cmb_capa.addItem(layer.name(), layer.id())

    def _cargar_csv(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar archivo",
            "", "Archivos (*.csv *.xlsx *.xls)"
        )
        if not fp:
            return
        self.lbl_csv.setText(os.path.basename(fp))
        self._csv_path = fp

        # Intentar cargar con el loader del crime_analyst plugin si está disponible
        try:
            import sys
            # Buscar el módulo del plugin hermano
            for path in sys.path:
                loader_path = os.path.join(path, "crime_analyst_cba", "modules", "data_loader.py")
                if os.path.exists(loader_path):
                    import importlib.util
                    spec = importlib.util.spec_from_file_location("data_loader", loader_path)
                    dl = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(dl)
                    self.gdf = dl.load_file(fp)
                    self._poblar_filtros()
                    self._set_status(f"Cargados {len(self.gdf):,} registros desde {os.path.basename(fp)}")
                    return
        except Exception:
            pass

        # Fallback: carga directa con geopandas
        try:
            import pandas as pd
            import geopandas as gpd
            ext = os.path.splitext(fp)[1].lower()
            if ext in (".xlsx", ".xls"):
                df = pd.read_excel(fp)
            else:
                try:
                    df = pd.read_csv(fp, low_memory=False)
                except UnicodeDecodeError:
                    df = pd.read_csv(fp, encoding="latin-1", low_memory=False)

            # Detectar columnas de coordenadas
            col_lat = next((c for c in df.columns if c.lower() in ["latitud","lat","y"]), None)
            col_lon = next((c for c in df.columns if c.lower() in ["longitud","lon","x"]), None)
            if not col_lat or not col_lon:
                raise ValueError("No se encontraron columnas de coordenadas.")

            df[col_lat] = pd.to_numeric(df[col_lat], errors="coerce")
            df[col_lon] = pd.to_numeric(df[col_lon], errors="coerce")
            df = df.dropna(subset=[col_lat, col_lon])

            # Parsear fecha
            for col_f in ["fecha_hora", "fecha_hech", "fecha", "date"]:
                if col_f in df.columns:
                    df["fecha_hora"] = pd.to_datetime(df[col_f], infer_datetime_format=True, dayfirst=False)
                    break

            # Normalizar tipo_delito
            for col_t in ["prevenible", "tipo_delito", "delito", "tipo"]:
                if col_t in df.columns:
                    df["tipo_delito"] = df[col_t]
                    break

            # Normalizar distrito
            for col_d in ["distrito", "distrito_policial"]:
                if col_d in df.columns:
                    df["distrito"] = df[col_d]
                    break

            self.gdf = gpd.GeoDataFrame(
                df,
                geometry=gpd.points_from_xy(df[col_lon], df[col_lat]),
                crs="EPSG:4326"
            )
            self._poblar_filtros()
            self._set_status(f"Cargados {len(self.gdf):,} registros.")
        except Exception as e:
            QMessageBox.critical(self, "Error al cargar", str(e))

    def _poblar_filtros(self):
        if self.gdf is None:
            return
        self.cmb_tipo.clear()
        self.cmb_tipo.addItem("Todos los tipos de delito")
        if "tipo_delito" in self.gdf.columns:
            tipos = sorted(self.gdf["tipo_delito"].dropna().unique().tolist())
            self.cmb_tipo.addItems([str(t) for t in tipos])

        self.cmb_distrito.clear()
        self.cmb_distrito.addItem("Todos los distritos")
        if "distrito" in self.gdf.columns:
            distritos = sorted(self.gdf["distrito"].dropna().unique().tolist())
            self.cmb_distrito.addItems([str(d) for d in distritos])

    def _get_gdf(self):
        """Obtiene el GeoDataFrame de la fuente seleccionada."""
        if self.radio_csv.isChecked():
            if self.gdf is None:
                raise ValueError("Cargá un archivo CSV primero.")
            return self.gdf

        # Desde capa QGIS
        layer_id = self.cmb_capa.currentData()
        if not layer_id:
            raise ValueError("Seleccioná una capa de puntos del proyecto.")

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer:
            raise ValueError("La capa seleccionada no está disponible.")

        import geopandas as gpd
        features = list(layer.getFeatures())
        if not features:
            raise ValueError("La capa no tiene features.")

        fields = [f.name() for f in layer.fields()]
        rows = []
        for feat in features:
            row = dict(zip(fields, feat.attributes()))
            row["lon"] = feat.geometry().asPoint().x()
            row["lat"] = feat.geometry().asPoint().y()
            rows.append(row)

        import pandas as pd
        df = pd.DataFrame(rows)

        # Normalizar columnas necesarias
        for col_f in ["fecha_hora", "fecha_hech", "fecha"]:
            if col_f in df.columns:
                df["fecha_hora"] = pd.to_datetime(df[col_f], infer_datetime_format=True, dayfirst=False)
                break

        for col_t in ["prevenible", "tipo_delito", "delito"]:
            if col_t in df.columns and "tipo_delito" not in df.columns:
                df["tipo_delito"] = df[col_t]
                break

        gdf = gpd.GeoDataFrame(
            df,
            geometry=gpd.points_from_xy(df["lon"], df["lat"]),
            crs="EPSG:4326"
        )
        self.gdf = gdf
        self._poblar_filtros()
        return gdf

    def _run_analisis(self):
        try:
            gdf = self._get_gdf()
        except Exception as e:
            QMessageBox.warning(self, "Sin datos", str(e))
            return

        from ..modules.knox_test import preparar_datos, knox_montecarlo

        tipo     = self.cmb_tipo.currentText()
        tipo     = None if tipo.startswith("Todos") else tipo
        distrito = self.cmb_distrito.currentText()
        distrito = None if distrito.startswith("Todos") else distrito

        dist_u   = self.spin_dist.value()
        tiempo_u = self.spin_tiempo.value()
        n_sim    = self.spin_sim.value()

        capas_activas = {
            "puntos":  self.chk_puntos.isChecked(),
            "buffers": self.chk_buffers.isChecked(),
            "lineas":  self.chk_lineas.isChecked(),
            "heatmap": self.chk_heatmap.isChecked(),
        }

        self._set_status(f"Ejecutando Knox test ({n_sim} simulaciones)...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)

        def _run():
            from ..modules.knox_test import preparar_datos, knox_montecarlo, interpretar_resultado
            from ..modules.layer_builder import generar_todas_las_capas

            df_prep = preparar_datos(gdf, tipo_delito=tipo, distrito=distrito)
            resultado = knox_montecarlo(df_prep, dist_u, tiempo_u, n_sim)
            interpretacion = interpretar_resultado(resultado)
            capas = generar_todas_las_capas(resultado, tipo, capas_activas)
            return resultado, interpretacion, capas

        self._worker = AnalysisWorker(_run)
        self._worker.finished.connect(self._on_analisis_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_analisis_done(self, result):
        self.progress.setVisible(False)
        resultado, interpretacion, capas_result = result
        self.resultado_kr = resultado
        self.capas_gen    = capas_result["capas"]

        # Mostrar resultado textual
        self.txt_resultado.setPlainText(interpretacion)
        self.tabs.setCurrentIndex(1)

        # Gráfico de distribución Monte Carlo
        if MATPLOTLIB_OK:
            self._plot_distribucion(resultado)

        # Resumen de riesgo
        resumen = capas_result["resumen_riesgo"]
        labels  = {0: "Sin riesgo NR", 1: "Riesgo bajo", 2: "Riesgo medio", 3: "Riesgo alto"}
        txt = "Distribución de eventos por nivel de riesgo near repeat:\n\n"
        for nivel, cnt in sorted(resumen.items()):
            txt += f"  {labels.get(nivel, nivel)}: {cnt} eventos\n"
        df_p = capas_result["df_pares"]
        txt += f"\nTotal de pares near repeat: {len(df_p)}\n"
        if len(df_p) > 0:
            txt += f"Distancia promedio entre pares: {df_p['distancia_m'].mean():.0f} m\n"
            txt += f"Diferencia temporal promedio:   {df_p['diff_dias'].mean():.1f} días\n"
        self.txt_resumen_riesgo.setPlainText(txt)

        n_obs  = resultado["n_obs"]
        p      = resultado["p_valor"]
        ratio  = resultado["knox_ratio"]
        self._set_status(
            f"Análisis completado. n_obs={n_obs} | Knox ratio={ratio:.3f} | p={p:.4f}"
        )

    def _run_multibanda(self):
        try:
            gdf = self._get_gdf()
        except Exception as e:
            QMessageBox.warning(self, "Sin datos", str(e))
            return

        from ..modules.knox_test import preparar_datos

        tipo     = self.cmb_tipo.currentText()
        tipo     = None if tipo.startswith("Todos") else tipo
        distrito = self.cmb_distrito.currentText()
        distrito = None if distrito.startswith("Todos") else distrito

        banda_d  = self.spin_banda_dist.value()
        n_bd     = self.spin_n_bandas_dist.value()
        banda_t  = self.spin_banda_tiempo.value()
        n_bt     = self.spin_n_bandas_tiempo.value()
        n_sim    = self.spin_sim.value()

        bandas_dist   = [i * banda_d for i in range(n_bd + 1)]
        bandas_tiempo = [i * banda_t for i in range(n_bt + 1)]

        self._set_status(f"Ejecutando análisis multibanda ({n_sim} sim)...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)

        def _run():
            from ..modules.knox_test import preparar_datos, knox_multibanda
            df_prep = preparar_datos(gdf, tipo_delito=tipo, distrito=distrito)
            return knox_multibanda(df_prep, bandas_dist, bandas_tiempo, n_sim)

        self._worker = AnalysisWorker(_run)
        self._worker.finished.connect(self._on_multibanda_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_multibanda_done(self, resultado):
        self.progress.setVisible(False)
        self.resultado_mb = resultado
        self._set_status("Análisis multibanda completado.")
        self.tabs.setCurrentIndex(1)

        # Formatear tabla
        p_mat    = resultado["p_matrix"]
        r_mat    = resultado["ratio_matrix"]
        obs_mat  = resultado["obs_counts"]
        etiq_d   = resultado["etiq_dist"]
        etiq_t   = resultado["etiq_tiempo"]

        ancho_col = 22
        lineas = []
        lineas.append("MATRIZ MULTIBANDA — KNOX TEST")
        lineas.append(f"Simulaciones: {resultado['n_sim']}")
        lineas.append("")
        lineas.append("p-valor  (Knox ratio)  [obs]   — * p<0.05  ** p<0.01")
        lineas.append("")

        # Encabezado temporal
        header = "Dist\\Tiempo".ljust(18)
        for et in etiq_t:
            header += et.center(ancho_col)
        lineas.append(header)
        lineas.append("─" * (18 + ancho_col * len(etiq_t)))

        for di, ed in enumerate(etiq_d):
            fila = ed.ljust(18)
            for ti in range(len(etiq_t)):
                p   = p_mat[di, ti]
                r   = r_mat[di, ti]
                obs = obs_mat[di, ti]
                sig = "**" if p <= 0.01 else ("*" if p <= 0.05 else "  ")
                celda = f"{p:.3f}({r:.2f})[{obs}]{sig}"
                fila += celda.center(ancho_col)
            lineas.append(fila)

        self.txt_multibanda.setPlainText("\n".join(lineas))

    def _plot_distribucion(self, resultado):
        """Gráfico de la distribución de simulaciones Monte Carlo."""
        self.fig_dist.clear()
        ax = self.fig_dist.add_subplot(111)

        sim = resultado["sim_counts"]
        n_obs = resultado["n_obs"]
        p = resultado["p_valor"]

        ax.hist(sim, bins=30, color="#378ADD", alpha=0.8, edgecolor="#1F4E79", linewidth=0.5)
        ax.axvline(n_obs, color="#CC0000", linewidth=2, linestyle="--",
                   label=f"Observado: {n_obs}")
        ax.set_xlabel("Pares near repeat (simulaciones)")
        ax.set_ylabel("Frecuencia")
        ax.set_title(f"Distribución Monte Carlo  |  p = {p:.4f}")
        ax.legend()
        self.fig_dist.tight_layout()
        self.canvas_dist.draw()

    def _zoom_capas(self):
        """Zoom a la extensión de las capas NR generadas."""
        from qgis.core import QgsRectangle
        extent = None
        for capa in self.capas_gen.values():
            if capa and capa.isValid():
                ext = capa.extent()
                if extent is None:
                    extent = ext
                else:
                    extent.combineExtentWith(ext)
        if extent and self.iface:
            self.iface.mapCanvas().setExtent(extent)
            self.iface.mapCanvas().refresh()

    def _exportar_capas(self):
        """Exporta todas las capas NR a un GeoPackage."""
        if not self.capas_gen:
            QMessageBox.warning(self, "Sin capas", "Ejecutá el análisis primero.")
            return
        fp, _ = QFileDialog.getSaveFileName(
            self, "Guardar GeoPackage", "near_repeat_cba.gpkg",
            "GeoPackage (*.gpkg)"
        )
        if not fp:
            return

        from qgis.core import QgsVectorFileWriter, QgsCoordinateTransformContext
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        first = True
        for nombre, capa in self.capas_gen.items():
            if capa and capa.isValid():
                opts.layerName = nombre
                opts.actionOnExistingFile = (
                    QgsVectorFileWriter.CreateOrOverwriteFile if first
                    else QgsVectorFileWriter.CreateOrOverwriteLayer
                )
                QgsVectorFileWriter.writeAsVectorFormatV3(
                    capa, fp,
                    QgsCoordinateTransformContext(), opts
                )
                first = False

        QMessageBox.information(self, "Exportado",
                                f"Capas guardadas en:\n{fp}")

    def _set_status(self, msg):
        self.status.setText(msg)

    def _on_error(self, msg):
        self.progress.setVisible(False)
        self._set_status("Error.")
        QMessageBox.critical(self, "Error", msg)
        QgsMessageLog.logMessage(f"[NearRepeat] ERROR: {msg}",
                                 "NearRepeatCBA", Qgis.Critical)
