# Crime Analyst CBA — Plugin QGIS
## Cátedra Mapeo Delictivo · Licenciatura en Seguridad · UNVM

---

## Requisitos previos

- QGIS 3.22 o superior (recomendado: 3.44)
- Python 3.9+ (incluido con QGIS)
- Ollama instalado y corriendo (https://ollama.com)
- Modelo Llama 3.2 descargado

---

## Instalación paso a paso

### 1. Instalar Ollama y descargar el modelo

```bash
# Descargar Ollama desde https://ollama.com/download
# Luego, en terminal:
ollama pull llama3.2
ollama serve           # dejar corriendo en segundo plano
```

### 2. Instalar dependencias Python en QGIS

Abrí la Consola Python de QGIS (Complementos → Consola Python de QGIS) y ejecutá:

```python
import subprocess, sys, os

plugin_dir = os.path.join(os.path.expanduser("~"), ".local", "share", "QGIS",
                          "QGIS3", "profiles", "default", "python", "plugins",
                          "crime_analyst_cba")

subprocess.run([
    sys.executable, "-m", "pip", "install",
    "-r", os.path.join(plugin_dir, "requirements.txt")
], check=True)
print("Dependencias instaladas correctamente.")
```

### 3. Instalar el plugin en QGIS

1. Comprimir la carpeta `crime_analyst_cba/` en un ZIP: `crime_analyst_cba.zip`
2. En QGIS: **Complementos → Administrar e instalar complementos**
3. Pestaña **Instalar desde ZIP**
4. Seleccionar `crime_analyst_cba.zip` → **Instalar complemento**
5. El plugin aparecerá en el menú **Complementos → Crime Analyst CBA**

---

## Uso básico

### Pestaña 1 · Datos
- Cargar archivo CSV, Excel o SHP con datos de delitos
- Verificar que Ollama está corriendo con el botón "Verificar conexión"

### Pestaña 2 · Espacial (KDE)
- Seleccionar filtros: tipo de delito, distrito, período
- **Generar KDE**: crea una capa raster de hotspots en el mapa
- **Generar predicción**: KDE ponderado estacionalmente para próxima semana/mes

### Pestaña 3 · Temporal
- Generar gráficos de tendencia, estacionalidad, distribución horaria
- El heatmap hora×día es especialmente útil para planificación de patrullaje

### Pestaña 4 · Narrativa LLM
- Configurar tipo de informe y horizonte temporal
- **Generar narrativa táctica**: Llama 3.2 genera el informe en español policial
- **Exportar a TXT**: guarda el informe para elevar a la jefatura

---

## Formato de datos esperado

### CSV / Excel (EPSG:4326)
| latitud   | longitud   | fecha_hora          | tipo_delito | distrito |
|-----------|------------|---------------------|-------------|----------|
| -31.4135  | -64.1811   | 2023-03-15 22:30:00 | Robo        | D1       |

Columnas aceptadas para cada campo:
- **latitud**: `latitud`, `lat`, `y`, `coord_y`
- **longitud**: `longitud`, `lon`, `x`, `coord_x`
- **fecha**: `fecha_hora`, `fecha`, `date`, `datetime`, `fecha_hecho`
- **tipo**: `tipo_delito`, `delito`, `tipo`, `categoria`, `hecho`
- **distrito**: `distrito`, `distrito_policial`, `seccional`, `division_policial`

### SHP (POSGAR 98)
- Geometría de puntos
- El plugin detecta automáticamente POSGAR 98 y reproyecta a WGS84
- Los atributos deben seguir las mismas convenciones de nombres

---

## Solución de problemas

| Problema | Solución |
|----------|----------|
| "No se pudo conectar con Ollama" | Ejecutar `ollama serve` en terminal |
| "Modelo no disponible" | Ejecutar `ollama pull llama3.2` |
| "rasterio no instalado" | Reinstalar dependencias (paso 2) |
| "Insuficientes puntos para KDE" | Ampliar filtros de tipo/distrito/período |
| Plugin no aparece en QGIS | Verificar que está habilitado en Administrador de complementos |

---

## Notas de confidencialidad

Este plugin procesa datos **localmente**. El modelo LLM (Llama 3.2) corre en la máquina local mediante Ollama. **Ningún dato se envía a servicios externos.**

Los informes generados son de uso interno y deben tratarse según los protocolos de manejo de información sensible de la institución.

---

## Contacto

Cátedra Mapeo Delictivo — Licenciatura en Seguridad  
Universidad Nacional de Villa María  
