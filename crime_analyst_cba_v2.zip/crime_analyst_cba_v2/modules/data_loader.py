# -*- coding: utf-8 -*-
"""
modules/data_loader.py

Carga datos de delitos del sistema DPAD de Córdoba.

Estructura real de los archivos:
  id, prevenible, fecha_hech, hora_hecho, calle, barrio,
  distrito, comisaria, zona, cuadrantes, latitud, longitud,
  X, Y, fecha_hora

  - prevenible  → tipo de delito (RYH VP, ASALTO DOM, etc.)
  - fecha_hora  → datetime combinado ya disponible
  - distrito    → DISTRITO I ... DISTRITO XIII
  - zona        → ZONA NORTE, ZONA SUR, etc.
  - latitud/longitud → WGS84, no requieren reproyección

También acepta SHP con POSGAR 98 (reproyecta automáticamente).
"""

import os
import pandas as pd
import geopandas as gpd
from pyproj import CRS
from qgis.core import QgsMessageLog, Qgis

CRS_WGS84       = "EPSG:4326"
CRS_POSGAR98_F3 = "EPSG:22183"

# ---------------------------------------------------------------------------
# Aliases de columnas — prioriza los nombres reales del DPAD Córdoba
# ---------------------------------------------------------------------------
COL_ALIASES = {
    "latitud":     ["latitud", "lat", "latitude", "y_wgs", "coord_y"],
    "longitud":    ["longitud", "lon", "lng", "longitude", "x_wgs", "coord_x"],
    "fecha_hora":  ["fecha_hora", "fecha_hech", "fecha", "date", "datetime",
                    "fecha_hecho", "fecha_evento", "fecha_delito"],
    "hora":        ["hora_hecho", "hora", "hour"],
    "tipo_delito": ["prevenible", "tipo_delito", "delito", "tipo",
                    "categoria", "hecho", "clase_delito"],
    "distrito":    ["distrito", "distrito_policial", "seccional",
                    "division_policial"],
    "zona":        ["zona", "zona_policial", "area"],
    "barrio":      ["barrio", "neighborhood"],
    "comisaria":   ["comisaria", "seccional_nombre"],
    "calle":       ["calle", "direccion", "address"],
}

# Etiquetas legibles para los códigos del DPAD
LABELS_DELITO = {
    "RYH VP":          "Robo y hurto en vía pública",
    "RYH DOM":         "Robo y hurto domiciliario",
    "ASALTO VP":       "Asalto en vía pública",
    "ASALTO DOM":      "Asalto domiciliario",
    "RYH AUTO VP S/A": "Robo automotor vía pública s/armas",
    "RYH AUTO VP C/A": "Robo automotor vía pública c/armas",
    "RYH AUTO DOM S/A":"Robo automotor domicilio s/armas",
    "RYH AUTO DOM C/A":"Robo automotor domicilio c/armas",
}


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    col_map = {}
    cols_lower = {c.lower().strip(): c for c in df.columns}
    for canonical, aliases in COL_ALIASES.items():
        if canonical in df.columns:
            continue
        for alias in aliases:
            if alias.lower() in cols_lower:
                col_map[cols_lower[alias.lower()]] = canonical
                break
    return df.rename(columns=col_map)


def _parse_dates(df: pd.DataFrame) -> pd.DataFrame:
    if "fecha_hora" not in df.columns:
        return df
    try:
        df["fecha_hora"] = pd.to_datetime(
            df["fecha_hora"], dayfirst=False, infer_datetime_format=True
        )
    except Exception:
        try:
            df["fecha_hora"] = pd.to_datetime(df["fecha_hora"], dayfirst=True)
        except Exception as e:
            QgsMessageLog.logMessage(
                f"[CrimeAnalyst] No se pudo parsear fecha_hora: {e}",
                "CrimeAnalystCBA", Qgis.Warning
            )
            return df

    df["anio"]       = df["fecha_hora"].dt.year
    df["mes"]        = df["fecha_hora"].dt.month
    df["dia_semana"] = df["fecha_hora"].dt.dayofweek
    if "hora" not in df.columns:
        df["hora"] = df["fecha_hora"].dt.hour
    else:
        df["hora"] = pd.to_numeric(
            df["hora"].astype(str).str.split(":").str[0], errors="coerce"
        ).fillna(df["fecha_hora"].dt.hour)
    return df


def load_csv_excel(filepath: str) -> gpd.GeoDataFrame:
    ext = os.path.splitext(filepath)[1].lower()
    try:
        if ext in (".xlsx", ".xls"):
            df = pd.read_excel(filepath)
        else:
            try:
                df = pd.read_csv(filepath, encoding="utf-8", low_memory=False)
            except UnicodeDecodeError:
                df = pd.read_csv(filepath, encoding="latin-1", low_memory=False)
    except Exception as e:
        raise RuntimeError(f"Error al leer el archivo: {e}")

    df = _normalize_columns(df)
    df = _parse_dates(df)

    if "latitud" not in df.columns or "longitud" not in df.columns:
        raise ValueError(
            "No se encontraron columnas de coordenadas.\n"
            f"Columnas disponibles: {', '.join(df.columns.tolist())}"
        )

    df["latitud"]  = pd.to_numeric(df["latitud"],  errors="coerce")
    df["longitud"] = pd.to_numeric(df["longitud"], errors="coerce")
    df = df.dropna(subset=["latitud", "longitud"])

    df = df[
        (df["latitud"].between(-32.2, -31.0)) &
        (df["longitud"].between(-64.8, -63.8))
    ]

    if len(df) == 0:
        raise ValueError(
            "Ningún registro dentro del rango de coordenadas de Córdoba."
        )

    gdf = gpd.GeoDataFrame(
        df,
        geometry=gpd.points_from_xy(df["longitud"], df["latitud"]),
        crs=CRS_WGS84
    )
    QgsMessageLog.logMessage(
        f"[CrimeAnalyst] {len(gdf):,} registros desde {os.path.basename(filepath)}",
        "CrimeAnalystCBA", Qgis.Info
    )
    return gdf


def load_shp(filepath: str) -> gpd.GeoDataFrame:
    gdf = gpd.read_file(filepath)
    gdf = _normalize_columns(gdf)
    gdf = _parse_dates(gdf)
    if gdf.crs is None:
        gdf = gdf.set_crs(CRS_POSGAR98_F3)
    if not gdf.crs.equals(CRS(CRS_WGS84)):
        gdf = gdf.to_crs(CRS_WGS84)
    if not all(gdf.geometry.geom_type == "Point"):
        gdf["geometry"] = gdf.geometry.centroid
    gdf["longitud"] = gdf.geometry.x
    gdf["latitud"]  = gdf.geometry.y
    return gdf


def load_multiple_csv(filepaths: list) -> gpd.GeoDataFrame:
    """Carga y concatena múltiples CSV (un archivo por año)."""
    gdfs = []
    for fp in filepaths:
        try:
            gdfs.append(load_csv_excel(fp))
        except Exception as e:
            QgsMessageLog.logMessage(
                f"[CrimeAnalyst] Error en {os.path.basename(fp)}: {e}",
                "CrimeAnalystCBA", Qgis.Warning
            )
    if not gdfs:
        raise ValueError("No se pudo cargar ningún archivo.")
    combined = pd.concat(gdfs, ignore_index=True)
    return gpd.GeoDataFrame(
        combined,
        geometry=gpd.points_from_xy(combined["longitud"], combined["latitud"]),
        crs=CRS_WGS84
    )


def load_file(filepath: str) -> gpd.GeoDataFrame:
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".shp":
        return load_shp(filepath)
    elif ext in (".csv", ".txt", ".xlsx", ".xls"):
        return load_csv_excel(filepath)
    else:
        raise ValueError(f"Formato no soportado: {ext}")


def get_summary(gdf: gpd.GeoDataFrame) -> dict:
    summary = {
        "total_registros": len(gdf),
        "periodo":         None,
        "tipos_delito":    [],
        "distritos":       [],
        "zonas":           [],
        "anios":           [],
    }
    if "fecha_hora" in gdf.columns and gdf["fecha_hora"].notna().any():
        summary["periodo"] = {
            "desde": str(gdf["fecha_hora"].min().date()),
            "hasta": str(gdf["fecha_hora"].max().date()),
        }
    if "tipo_delito" in gdf.columns:
        conteo = gdf["tipo_delito"].value_counts()
        summary["tipos_delito"] = [
            {"tipo": k, "label": LABELS_DELITO.get(str(k), str(k)), "cantidad": int(v)}
            for k, v in conteo.items()
        ]
    if "distrito" in gdf.columns:
        summary["distritos"] = sorted(gdf["distrito"].dropna().unique().tolist())
    if "zona" in gdf.columns:
        summary["zonas"] = sorted(gdf["zona"].dropna().unique().tolist())
    if "anio" in gdf.columns:
        summary["anios"] = sorted(gdf["anio"].dropna().unique().astype(int).tolist())
    return summary
