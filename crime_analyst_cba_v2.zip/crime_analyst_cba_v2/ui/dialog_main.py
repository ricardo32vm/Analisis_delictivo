# -*- coding: utf-8 -*-
"""
ui/dialog_main.py  — v2

Panel principal del plugin Crime Analyst CBA.
Adaptado a los datos reales del DPAD Córdoba:
  - Columna tipo_delito = prevenible (RYH VP, ASALTO DOM, etc.)
  - Distritos: DISTRITO I … DISTRITO XIII
  - Zonas: ZONA NORTE, ZONA SUR, ZONA ESTE, ZONA OESTE, ZONA CENTRO, SIERRAS CHICAS
  - Carga de múltiples CSV (un archivo por año)
"""

import os
import traceback

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QPushButton, QLabel, QFileDialog, QComboBox,
    QTextEdit, QProgressBar, QGroupBox, QFormLayout,
    QSpinBox, QSizePolicy, QMessageBox, QRadioButton,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.core import QgsMessageLog, Qgis

try:
    import matplotlib
    matplotlib.use("Qt5Agg")
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    import matplotlib.pyplot as plt
    import numpy as np
    MATPLOTLIB_OK = True
except ImportError:
    MATPLOTLIB_OK = False


# ---------------------------------------------------------------------------
# Worker thread
# ---------------------------------------------------------------------------
class AnalysisWorker(QThread):
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func   = func
        self.args   = args
        self.kwargs = kwargs

    def run(self):
        try:
            self.finished.emit(self.func(*self.args, **self.kwargs))
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


# ---------------------------------------------------------------------------
# Diálogo principal
# ---------------------------------------------------------------------------
class CrimeAnalystDialog(QDialog):

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.gdf   = None
        self._ultimo_informe = ""
        self._last_hotspots  = []
        self._last_prediccion = {}
        self.setWindowTitle("Crime Analyst CBA — UNVM")
        self.setMinimumSize(860, 680)
        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)

        header = QLabel("Crime Analyst CBA  ·  Cátedra Mapeo Delictivo — UNVM")
        f = QFont(); f.setBold(True); f.setPointSize(11)
        header.setFont(f)
        header.setAlignment(Qt.AlignCenter)
        layout.addWidget(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_datos(),     "1 · Datos")
        self.tabs.addTab(self._tab_espacial(),  "2 · Espacial (KDE)")
        self.tabs.addTab(self._tab_temporal(),  "3 · Temporal")
        self.tabs.addTab(self._tab_narrativa(), "4 · Narrativa LLM")
        layout.addWidget(self.tabs)

        self.status_bar = QLabel("Esperando carga de datos...")
        self.status_bar.setStyleSheet("color: gray; font-size: 11px;")
        layout.addWidget(self.status_bar)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.close)
        layout.addWidget(btn_cerrar)

    # ------------------------------------------------------------------
    # TAB 1: Datos
    # ------------------------------------------------------------------
    def _tab_datos(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp = QGroupBox("Cargar datos de delitos (DPAD Córdoba)")
        grp_layout = QFormLayout(grp)

        self.lbl_archivo = QLabel("Sin archivo seleccionado")

        btn_uno = QPushButton("Un archivo (CSV / Excel / SHP)...")
        btn_uno.clicked.connect(self._cargar_archivo)

        btn_multi = QPushButton("Múltiples años (varios CSV)...")
        btn_multi.clicked.connect(self._cargar_multiples)

        row_btn = QHBoxLayout()
        row_btn.addWidget(btn_uno)
        row_btn.addWidget(btn_multi)

        grp_layout.addRow("Archivo:", self.lbl_archivo)
        grp_layout.addRow("", row_btn)
        layout.addWidget(grp)

        grp2 = QGroupBox("Resumen del dataset")
        grp2_l = QVBoxLayout(grp2)
        self.txt_resumen = QTextEdit()
        self.txt_resumen.setReadOnly(True)
        self.txt_resumen.setMaximumHeight(220)
        self.txt_resumen.setPlaceholderText(
            "El resumen aparecerá aquí después de cargar datos.\n\n"
            "Formatos: CSV, Excel (.xlsx), SHP\n"
            "Para cargar todos los años a la vez usá 'Múltiples años'."
        )
        grp2_l.addWidget(self.txt_resumen)
        layout.addWidget(grp2)

        grp3 = QGroupBox("Estado de Ollama (LLM local)")
        grp3_l = QHBoxLayout(grp3)
        self.lbl_ollama = QLabel("Sin verificar")
        btn_ver = QPushButton("Verificar conexión")
        btn_ver.clicked.connect(self._verificar_ollama)
        grp3_l.addWidget(self.lbl_ollama)
        grp3_l.addWidget(btn_ver)
        layout.addWidget(grp3)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # TAB 2: Espacial
    # ------------------------------------------------------------------
    def _tab_espacial(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp = QGroupBox("Filtros del análisis espacial")
        form = QFormLayout(grp)

        self.cmb_tipo_kde     = QComboBox()
        self.cmb_distrito_kde = QComboBox()
        self.cmb_zona_kde     = QComboBox()

        self.spin_anio_desde = QSpinBox()
        self.spin_anio_desde.setRange(2015, 2030)
        self.spin_anio_desde.setValue(2019)
        self.spin_anio_hasta = QSpinBox()
        self.spin_anio_hasta.setRange(2015, 2030)
        self.spin_anio_hasta.setValue(2023)

        row_anio = QHBoxLayout()
        row_anio.addWidget(QLabel("Desde:"))
        row_anio.addWidget(self.spin_anio_desde)
        row_anio.addWidget(QLabel("Hasta:"))
        row_anio.addWidget(self.spin_anio_hasta)

        form.addRow("Tipo de delito:",    self.cmb_tipo_kde)
        form.addRow("Distrito policial:", self.cmb_distrito_kde)
        form.addRow("Zona policial:",     self.cmb_zona_kde)
        form.addRow("Período:",           row_anio)
        layout.addWidget(grp)

        grp_pred = QGroupBox("Predicción de zonas de riesgo")
        pred_l = QHBoxLayout(grp_pred)
        self.radio_semana = QRadioButton("Próxima semana")
        self.radio_mes    = QRadioButton("Próximo mes")
        self.radio_semana.setChecked(True)
        pred_l.addWidget(self.radio_semana)
        pred_l.addWidget(self.radio_mes)
        layout.addWidget(grp_pred)

        row_btn = QHBoxLayout()
        btn_kde  = QPushButton("Generar KDE (hotspots históricos)")
        btn_pred = QPushButton("Generar predicción de riesgo")
        btn_kde.clicked.connect(self._run_kde)
        btn_pred.clicked.connect(self._run_prediccion)
        row_btn.addWidget(btn_kde)
        row_btn.addWidget(btn_pred)
        layout.addLayout(row_btn)

        self.txt_kde_resultado = QTextEdit()
        self.txt_kde_resultado.setReadOnly(True)
        self.txt_kde_resultado.setMaximumHeight(160)
        self.txt_kde_resultado.setPlaceholderText(
            "Los resultados del análisis espacial aparecerán aquí.\n"
            "La capa KDE se agrega automáticamente al mapa de QGIS."
        )
        layout.addWidget(self.txt_kde_resultado)
        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # TAB 3: Temporal
    # ------------------------------------------------------------------
    def _tab_temporal(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp = QGroupBox("Filtros")
        form = QFormLayout(grp)
        self.cmb_tipo_temp = QComboBox()
        self.cmb_tipo_temp.addItem("Todos los delitos")
        form.addRow("Tipo de delito:", self.cmb_tipo_temp)
        layout.addWidget(grp)

        grp_g = QGroupBox("Gráficos")
        btn_l = QHBoxLayout(grp_g)
        for label, key in [
            ("Tendencia anual",     "tendencia"),
            ("Estacionalidad",      "estacionalidad"),
            ("Por día",             "diaria"),
            ("Heatmap hora × día",  "heatmap"),
            ("Comparar tipos",      "tipos"),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(lambda checked, k=key: self._plot_temporal(k))
            btn_l.addWidget(btn)
        layout.addWidget(grp_g)

        if MATPLOTLIB_OK:
            self.fig    = Figure(figsize=(8, 4), tight_layout=True)
            self.canvas = FigureCanvas(self.fig)
            self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            layout.addWidget(self.canvas)
        else:
            layout.addWidget(QLabel("matplotlib no instalado."))

        return w

    # ------------------------------------------------------------------
    # TAB 4: Narrativa
    # ------------------------------------------------------------------
    def _tab_narrativa(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp = QGroupBox("Configuración del informe")
        form = QFormLayout(grp)

        self.cmb_tipo_llm    = QComboBox()
        self.cmb_tipo_llm.addItem("Todos los delitos")
        self.cmb_horizon     = QComboBox()
        self.cmb_horizon.addItems(["Próxima semana", "Próximo mes"])
        self.cmb_tipo_informe = QComboBox()
        self.cmb_tipo_informe.addItems([
            "Informe completo (espacial + temporal)",
            "Solo análisis espacial (hotspots)",
            "Solo análisis temporal",
        ])
        form.addRow("Tipo de delito:",        self.cmb_tipo_llm)
        form.addRow("Horizonte predicción:",  self.cmb_horizon)
        form.addRow("Tipo de informe:",       self.cmb_tipo_informe)
        layout.addWidget(grp)

        row_btn = QHBoxLayout()
        btn_gen = QPushButton("Generar narrativa táctica")
        btn_exp = QPushButton("Exportar a TXT")
        btn_gen.clicked.connect(self._run_narrativa)
        btn_exp.clicked.connect(self._exportar_narrativa)
        row_btn.addWidget(btn_gen)
        row_btn.addWidget(btn_exp)
        layout.addLayout(row_btn)

        self.txt_narrativa = QTextEdit()
        self.txt_narrativa.setReadOnly(True)
        self.txt_narrativa.setPlaceholderText(
            "El informe táctico generado por Llama 3.2 aparecerá aquí.\n\n"
            "Asegurate de que Ollama esté corriendo (bandeja del sistema)\n"
            "y verificá la conexión en la pestaña Datos."
        )
        layout.addWidget(self.txt_narrativa)
        return w

    # ------------------------------------------------------------------
    # Acciones: carga de datos
    # ------------------------------------------------------------------
    def _cargar_archivo(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar archivo",
            "", "Archivos soportados (*.csv *.xlsx *.xls *.shp);;Todos (*)"
        )
        if not fp:
            return
        self.lbl_archivo.setText(os.path.basename(fp))
        self._iniciar_carga(lambda: __import__(
            'crime_analyst_cba.modules.data_loader',
            fromlist=["load_file"]
        ))
        # Usar worker
        from ..modules.data_loader import load_file
        self._lanzar_worker(lambda: load_file(fp), self._on_datos_cargados)

    def _cargar_multiples(self):
        fps, _ = QFileDialog.getOpenFileNames(
            self, "Seleccionar archivos CSV (podés elegir varios)",
            "", "CSV (*.csv)"
        )
        if not fps:
            return
        self.lbl_archivo.setText(f"{len(fps)} archivos seleccionados")
        from ..modules.data_loader import load_multiple_csv
        self._lanzar_worker(lambda: load_multiple_csv(fps), self._on_datos_cargados)

    def _lanzar_worker(self, func, on_done):
        self._set_status("Procesando...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self._worker = AnalysisWorker(func)
        self._worker.finished.connect(on_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_datos_cargados(self, gdf):
        self.gdf = gdf
        self.progress.setVisible(False)

        from ..modules.data_loader import get_summary
        r = get_summary(gdf)

        txt = f"Registros cargados:  {r['total_registros']:,}\n"
        if r["periodo"]:
            txt += f"Período:             {r['periodo']['desde']} → {r['periodo']['hasta']}\n"
        if r["anios"]:
            txt += f"Años disponibles:    {', '.join(map(str, r['anios']))}\n"
        if r["distritos"]:
            txt += f"Distritos:           {len(r['distritos'])} ({', '.join(r['distritos'][:4])}{'...' if len(r['distritos'])>4 else ''})\n"
        if r["zonas"]:
            txt += f"Zonas:               {', '.join(r['zonas'])}\n"
        if r["tipos_delito"]:
            txt += "\nTipos de delito:\n"
            for t in r["tipos_delito"]:
                txt += f"  · {t['tipo']:25s} {t['cantidad']:,} hechos  ({t['label']})\n"

        self.txt_resumen.setText(txt)

        # Poblar combos
        tipos    = ["Todos los delitos"] + [t["tipo"] for t in r["tipos_delito"]]
        distritos = ["Todos los distritos"] + r["distritos"]
        zonas    = ["Todas las zonas"] + r["zonas"]

        for cmb in [self.cmb_tipo_kde, self.cmb_tipo_temp, self.cmb_tipo_llm]:
            cmb.clear(); cmb.addItems(tipos)

        self.cmb_distrito_kde.clear(); self.cmb_distrito_kde.addItems(distritos)
        self.cmb_zona_kde.clear();     self.cmb_zona_kde.addItems(zonas)

        if r["anios"]:
            self.spin_anio_desde.setValue(min(r["anios"]))
            self.spin_anio_hasta.setValue(max(r["anios"]))

        self._set_status(f"Datos cargados: {r['total_registros']:,} registros.")

    def _verificar_ollama(self):
        from ..modules.llm_narrative import check_ollama_available
        ok, msg = check_ollama_available()
        self.lbl_ollama.setStyleSheet(f"color: {'green' if ok else 'red'};")
        self.lbl_ollama.setText(msg)

    # ------------------------------------------------------------------
    # KDE y predicción
    # ------------------------------------------------------------------
    def _get_filtros(self, cmb_tipo, cmb_dist=None, cmb_zona=None):
        tipo = cmb_tipo.currentText()
        tipo = None if tipo.startswith("Todos") else tipo
        dist = None
        zona = None
        if cmb_dist:
            dist = cmb_dist.currentText()
            dist = None if dist.startswith("Todos") else dist
        if cmb_zona:
            zona = cmb_zona.currentText()
            zona = None if zona.startswith("Todas") else zona
        return tipo, dist, zona

    def _filtrar_gdf(self, tipo, dist, zona):
        """Aplica filtros al GeoDataFrame antes del KDE."""
        import geopandas as gpd
        data = self.gdf.copy()
        if tipo and "tipo_delito" in data.columns:
            data = data[data["tipo_delito"] == tipo]
        if dist and "distrito" in data.columns:
            data = data[data["distrito"] == dist]
        if zona and "zona" in data.columns:
            data = data[data["zona"] == zona]
        if "anio" in data.columns:
            data = data[
                (data["anio"] >= self.spin_anio_desde.value()) &
                (data["anio"] <= self.spin_anio_hasta.value())
            ]
        return data

    def _run_kde(self):
        if self.gdf is None:
            QMessageBox.warning(self, "Sin datos", "Cargá un archivo primero.")
            return
        tipo, dist, zona = self._get_filtros(
            self.cmb_tipo_kde, self.cmb_distrito_kde, self.cmb_zona_kde
        )
        data = self._filtrar_gdf(tipo, dist, zona)
        nombre = f"KDE — {tipo or 'Todos'}"

        from ..modules.spatial_analysis import compute_kde, add_kde_to_qgis, get_top_hotspots

        def _run():
            kde      = compute_kde(data)
            layer    = add_kde_to_qgis(kde, nombre)
            hotspots = get_top_hotspots(kde, n=5)
            return {"kde": kde, "hotspots": hotspots}

        self._lanzar_worker(_run, self._on_kde_done)

    def _on_kde_done(self, result):
        self.progress.setVisible(False)
        self._last_hotspots = result["hotspots"]
        txt = f"Capa KDE agregada al mapa.\nPuntos analizados: {result['kde']['n_puntos']:,}\n\nTop 5 hotspots:\n"
        for i, h in enumerate(result["hotspots"]):
            txt += f"  {i+1}. Lat {h['lat']}, Lon {h['lon']} — densidad {h['densidad']:.0f}/100\n"
        self.txt_kde_resultado.setText(txt)
        self._set_status("KDE generado.")

    def _run_prediccion(self):
        if self.gdf is None:
            QMessageBox.warning(self, "Sin datos", "Cargá un archivo primero.")
            return
        tipo, dist, zona = self._get_filtros(
            self.cmb_tipo_kde, self.cmb_distrito_kde, self.cmb_zona_kde
        )
        data    = self._filtrar_gdf(tipo, dist, zona)
        horizon = "semana" if self.radio_semana.isChecked() else "mes"

        from ..modules.spatial_analysis import predict_risk_zones, add_kde_to_qgis, get_top_hotspots

        def _run():
            result   = predict_risk_zones(data, horizon=horizon, tipo_delito=tipo)
            layer    = add_kde_to_qgis(result["kde_prediccion"],
                                       f"Predicción {horizon} — {tipo or 'Todos'}")
            hotspots = get_top_hotspots(result["kde_prediccion"], n=5)
            return {**result, "hotspots": hotspots}

        self._lanzar_worker(_run, self._on_prediccion_done)

    def _on_prediccion_done(self, result):
        self.progress.setVisible(False)
        self._last_prediccion = result
        txt = result["descripcion"] + "\n\nTop zonas de riesgo predichas:\n"
        for i, h in enumerate(result["hotspots"]):
            txt += f"  {i+1}. Lat {h['lat']}, Lon {h['lon']} — riesgo {h['densidad']:.0f}/100\n"
        self.txt_kde_resultado.setText(txt)
        self._set_status("Predicción generada.")

    # ------------------------------------------------------------------
    # Gráficos temporales
    # ------------------------------------------------------------------
    def _plot_temporal(self, tipo_grafico):
        if self.gdf is None:
            QMessageBox.warning(self, "Sin datos", "Cargá un archivo primero.")
            return
        if not MATPLOTLIB_OK:
            return

        tipo = self.cmb_tipo_temp.currentText()
        tipo = None if tipo.startswith("Todos") else tipo

        from ..modules import temporal_analysis as ta
        self.fig.clear()
        ax = self.fig.add_subplot(111)

        try:
            if tipo_grafico == "tendencia":
                d = ta.tendencia_anual(self.gdf, tipo)
                colores = ["#E24B4A" if c == max(d["conteos"]) else "#378ADD"
                           for c in d["conteos"]]
                ax.bar(d["anios"], d["conteos"], color=colores, alpha=0.85)
                ax.set_title("Tendencia anual de hechos delictivos — Córdoba")
                ax.set_xlabel("Año"); ax.set_ylabel("Hechos")
                for a, c in zip(d["anios"], d["conteos"]):
                    ax.text(a, c + max(d["conteos"])*0.01, f"{c:,}",
                            ha="center", va="bottom", fontsize=8)

            elif tipo_grafico == "estacionalidad":
                d = ta.estacionalidad_mensual(self.gdf, tipo)
                colores = ["#E24B4A" if v == max(d["valores"]) else
                           "#3B6D11" if v == min(d["valores"]) else "#378ADD"
                           for v in d["valores"]]
                ax.bar(d["meses"], d["valores"], color=colores, alpha=0.85)
                ax.axhline(1.0, color="gray", linestyle="--", lw=0.8, label="Promedio")
                ax.set_title("Índice estacional mensual")
                ax.set_ylabel("Índice (1.0 = promedio anual)")
                ax.legend()

            elif tipo_grafico == "diaria":
                d = ta.distribucion_diaria(self.gdf, tipo)
                colores = ["#E24B4A" if dia == d["dia_pico"] else "#378ADD"
                           for dia in d["dias"]]
                ax.bar(d["dias"], d["conteos"], color=colores, alpha=0.85)
                ax.set_title("Distribución por día de la semana")
                ax.set_ylabel("Hechos")
                ax.tick_params(axis="x", rotation=30)

            elif tipo_grafico == "heatmap":
                d = ta.mapa_calor_hora_dia(self.gdf, tipo)
                matrix = np.array(d["matrix"])
                im = ax.imshow(matrix, aspect="auto", cmap="YlOrRd",
                               extent=[-0.5, 6.5, 23.5, -0.5])
                self.fig.colorbar(im, ax=ax, label="Hechos")
                ax.set_xticks(range(7))
                ax.set_xticklabels(d["dias"], rotation=30, ha="right", fontsize=8)
                ax.set_ylabel("Hora del día")
                ax.set_title("Concentración delictiva: hora × día — Córdoba")

            elif tipo_grafico == "tipos":
                d = ta.comparar_tipos(self.gdf)
                colores = plt.cm.tab10.colors
                for i, s in enumerate(d["series"]):
                    ax.plot(d["anios"], s["valores"], marker="o",
                            label=s["tipo"], color=colores[i % 10])
                ax.set_title("Evolución por tipo de delito")
                ax.set_xlabel("Año"); ax.set_ylabel("Hechos")
                ax.legend(fontsize=8)

            self.fig.tight_layout()
            self.canvas.draw()

        except Exception as e:
            self._on_error(str(e))

    # ------------------------------------------------------------------
    # Narrativa LLM
    # ------------------------------------------------------------------
    def _run_narrativa(self):
        if self.gdf is None:
            QMessageBox.warning(self, "Sin datos", "Cargá un archivo primero.")
            return

        from ..modules import llm_narrative as llm
        from ..modules import temporal_analysis as ta
        from ..modules.spatial_analysis import compute_kde, get_top_hotspots, predict_risk_zones

        tipo     = self.cmb_tipo_llm.currentText()
        tipo     = None if tipo.startswith("Todos") else tipo
        horizon  = "semana" if "semana" in self.cmb_horizon.currentText().lower() else "mes"
        tipo_inf = self.cmb_tipo_informe.currentIndex()

        def _run():
            resumen_temp = ta.resumen_para_llm(self.gdf, tipo)
            kde_base     = compute_kde(self.gdf if tipo is None else
                           self.gdf[self.gdf["tipo_delito"] == tipo]
                           if "tipo_delito" in self.gdf.columns else self.gdf)
            hotspots     = get_top_hotspots(kde_base, n=5)
            pred         = predict_risk_zones(self.gdf, horizon=horizon, tipo_delito=tipo)

            if tipo_inf == 0:
                return llm.generar_informe_completo(
                    hotspots, pred["descripcion"],
                    resumen_temp, pred["descripcion"],
                    tipo_delito=tipo, horizon=horizon
                )
            elif tipo_inf == 1:
                return llm.generar_informe_hotspots(
                    hotspots, pred["descripcion"], tipo_delito=tipo
                )
            else:
                return llm.generar_informe_temporal(
                    resumen_temp, pred["descripcion"],
                    tipo_delito=tipo, horizon=horizon
                )

        self._lanzar_worker(_run, self._on_narrativa_done)

    def _on_narrativa_done(self, texto):
        self.progress.setVisible(False)
        self._ultimo_informe = texto
        self.txt_narrativa.setPlainText(texto)
        self._set_status("Informe generado.")

    def _exportar_narrativa(self):
        if not self._ultimo_informe:
            QMessageBox.warning(self, "Sin informe", "Generá el informe primero.")
            return
        fp, _ = QFileDialog.getSaveFileName(
            self, "Guardar informe", "informe_crime_analyst.txt",
            "Archivos de texto (*.txt)"
        )
        if fp:
            from ..modules.llm_narrative import exportar_informe_txt
            exportar_informe_txt(self._ultimo_informe, fp)
            QMessageBox.information(self, "Exportado", f"Guardado en:\n{fp}")

    # ------------------------------------------------------------------
    def _set_status(self, msg):
        self.status_bar.setText(msg)

    def _on_error(self, msg):
        self.progress.setVisible(False)
        self._set_status("Error.")
        QMessageBox.critical(self, "Error", msg)
        QgsMessageLog.logMessage(f"[CrimeAnalyst] ERROR: {msg}",
                                 "CrimeAnalystCBA", Qgis.Critical)
