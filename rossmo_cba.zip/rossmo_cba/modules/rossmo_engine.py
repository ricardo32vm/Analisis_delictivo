# -*- coding: utf-8 -*-
"""
modules/rossmo_engine.py

Implementación del algoritmo Criminal Geographic Targeting (CGT)
de Kim Rossmo (1996, 2000) para perfilamiento geográfico criminal.

Fórmula:
    P(i,j) = k · Σ[n=1..C] [φ_ij / (|Xi-xn| + |Yj-yn|)^f
                            + (1-φ_ij)·B^(g-f) / (2B - |Xi-xn| - |Yj-yn|)^g]

    donde:
        φ_ij = 1  si  |Xi-xn| + |Yj-yn| > B  (fuera del buffer)
        φ_ij = 0  si  |Xi-xn| + |Yj-yn| ≤ B  (dentro del buffer)
        B  = radio del buffer (zona de confort)
        f,g = exponentes de decaimiento por distancia
        k  = coeficiente de calibración
        C  = número de sitios de crimen

Referencia:
    Rossmo, D.K. (2000). Geographic Profiling. CRC Press.
    Suárez-Meaney et al. (2017). Predictibilidad locacional y
      perfilamiento geográfico en el homicidio serial con gvSIG.
      Revista Mapping, 26(182), 52-63.
"""

import numpy as np
import geopandas as gpd
import pandas as pd
from pyproj import Transformer
from qgis.core import QgsMessageLog, Qgis

# CRS métrico para Córdoba — POSGAR 2007 / Argentina faja 3
CRS_METRICA = "EPSG:5345"
CRS_WGS84   = "EPSG:4326"


def _manhattan(xi, yj, xn, yn):
    """Distancia Manhattan entre punto (xi, yj) y crimen (xn, yn)."""
    return abs(xi - xn) + abs(yj - yn)


def calcular_rossmo(crimen_coords: np.ndarray,
                    grid_x: np.ndarray,
                    grid_y: np.ndarray,
                    B: float = 500.0,
                    f: float = 1.0,
                    g: float = 1.0,
                    k: float = 1.0) -> np.ndarray:
    """
    Calcula la superficie de probabilidad de Rossmo sobre una grilla.

    Parámetros:
        crimen_coords : array (C, 2) con coordenadas (x, y) en metros
        grid_x        : array 1D de coordenadas x de la grilla
        grid_y        : array 1D de coordenadas y de la grilla
        B             : radio del buffer en metros
        f             : exponente exterior al buffer (zona de caza)
        g             : exponente interior al buffer (zona de confort)
        k             : coeficiente de calibración

    Retorna:
        prob_matrix : array 2D (len(grid_y), len(grid_x)) de probabilidades
                      normalizadas 0–100
    """
    nx = len(grid_x)
    ny = len(grid_y)
    C  = len(crimen_coords)

    # Vectorizar: grilla completa como meshgrid
    GX, GY = np.meshgrid(grid_x, grid_y)   # shape (ny, nx)
    prob = np.zeros((ny, nx), dtype=float)

    for n in range(C):
        xn, yn = crimen_coords[n]

        # Distancia Manhattan de cada celda al n-ésimo crimen
        md = np.abs(GX - xn) + np.abs(GY - yn)

        # Evitar división por cero en el denominador exterior
        md_safe = np.where(md == 0, 1e-10, md)

        # Máscara: φ = 1 fuera del buffer, φ = 0 dentro
        fuera  = md > B
        dentro = ~fuera

        # Término 1: fuera del buffer — decaimiento por distancia
        t1 = np.where(fuera, 1.0 / np.power(md_safe, f), 0.0)

        # Término 2: dentro del buffer — zona de confort
        den2 = (2.0 * B) - md
        den2_safe = np.where(den2 <= 0, 1e-10, den2)
        t2 = np.where(dentro,
                      (B ** (g - f)) / np.power(den2_safe, g),
                      0.0)

        prob += t1 + t2

    prob *= k

    # Normalizar a 0–100
    pmax = prob.max()
    if pmax > 0:
        prob = (prob / pmax) * 100.0

    return prob


def preparar_crimen_coords(gdf: gpd.GeoDataFrame) -> np.ndarray:
    """
    Proyecta los puntos de crimen a CRS métrico y retorna
    array (C, 2) con coordenadas en metros.
    """
    gdf_m = gdf.to_crs(CRS_METRICA)
    coords = np.array([(geom.x, geom.y) for geom in gdf_m.geometry])
    return coords


def construir_grilla(crimen_coords: np.ndarray,
                     paso: float = 100.0,
                     margen_pct: float = 0.5) -> tuple:
    """
    Construye la grilla de evaluación.

    El 'Área de caza' es el MBR de los crímenes extendido un 50%
    en cada dirección (convención de Rossmo).

    Parámetros:
        paso       : separación entre puntos de la grilla (metros)
        margen_pct : extensión del área de caza (0.5 = 50%)

    Retorna:
        (grid_x, grid_y, bbox) donde bbox = (xmin, xmax, ymin, ymax)
    """
    xmin, xmax = crimen_coords[:, 0].min(), crimen_coords[:, 0].max()
    ymin, ymax = crimen_coords[:, 1].min(), crimen_coords[:, 1].max()

    dx = (xmax - xmin) * margen_pct
    dy = (ymax - ymin) * margen_pct

    # Asegurar mínimo de extensión
    if dx < paso * 10:
        dx = paso * 20
    if dy < paso * 10:
        dy = paso * 20

    xmin_g = xmin - dx
    xmax_g = xmax + dx
    ymin_g = ymin - dy
    ymax_g = ymax + dy

    grid_x = np.arange(xmin_g, xmax_g + paso, paso)
    grid_y = np.arange(ymin_g, ymax_g + paso, paso)

    bbox = (xmin_g, xmax_g, ymin_g, ymax_g)
    return grid_x, grid_y, bbox


def punto_max_probabilidad(prob_matrix: np.ndarray,
                            grid_x: np.ndarray,
                            grid_y: np.ndarray) -> tuple:
    """
    Encuentra la celda con máxima probabilidad.
    Retorna (x_m, y_m) en CRS métrico.
    """
    idx = np.unravel_index(np.argmax(prob_matrix), prob_matrix.shape)
    row, col = idx
    return float(grid_x[col]), float(grid_y[row])


def calcular_cgt_hit_score(crimen_coords: np.ndarray,
                            prob_matrix: np.ndarray,
                            grid_x: np.ndarray,
                            grid_y: np.ndarray,
                            anchor_real: tuple = None) -> dict:
    """
    Calcula el CGT Hit Score (Rossmo, 2000):
      % del área de caza que debe buscarse para incluir al anchor point.

    Si se provee anchor_real (x, y) en CRS métrico, calcula el score
    usando ese punto. Si no, calcula el área del top 10% de probabilidad.

    Retorna dict con métricas del análisis.
    """
    paso_x = float(grid_x[1] - grid_x[0]) if len(grid_x) > 1 else 100.0
    paso_y = float(grid_y[1] - grid_y[0]) if len(grid_y) > 1 else 100.0
    area_celda = paso_x * paso_y  # m²

    area_caza_total = len(grid_x) * len(grid_y) * area_celda / 1e6  # km²

    resultado = {
        "n_crimenes":       len(crimen_coords),
        "area_caza_km2":    round(area_caza_total, 2),
        "prob_max":         100.0,
        "anchor_x_m":       None,
        "anchor_y_m":       None,
        "anchor_lon":       None,
        "anchor_lat":       None,
        "cgt_hit_score_pct": None,
        "area_busqueda_km2": None,
        "distancia_al_max_m": None,
    }

    # Punto de máxima probabilidad
    x_max, y_max = punto_max_probabilidad(prob_matrix, grid_x, grid_y)
    resultado["anchor_x_m"] = round(x_max, 1)
    resultado["anchor_y_m"] = round(y_max, 1)

    # Convertir a WGS84
    transformer = Transformer.from_crs(CRS_METRICA, CRS_WGS84, always_xy=True)
    lon, lat = transformer.transform(x_max, y_max)
    resultado["anchor_lon"] = round(lon, 6)
    resultado["anchor_lat"] = round(lat, 6)

    if anchor_real is not None:
        xr, yr = anchor_real
        # Distancia Manhattan entre punto real y máximo predicho
        dist = abs(x_max - xr) + abs(y_max - yr)
        resultado["distancia_al_max_m"] = round(dist, 0)

        # CGT Hit Score: % del área con probabilidad >= P(anchor_real)
        # Interpolamos la probabilidad en el anchor real
        ix = int(np.clip(round((xr - grid_x[0]) / paso_x), 0, len(grid_x)-1))
        iy = int(np.clip(round((yr - grid_y[0]) / paso_y), 0, len(grid_y)-1))
        p_anchor = float(prob_matrix[iy, ix])

        n_celdas_busqueda = int((prob_matrix >= p_anchor).sum())
        area_busqueda = n_celdas_busqueda * area_celda / 1e6
        cgt_hs = (area_busqueda / area_caza_total) * 100.0

        resultado["area_busqueda_km2"]  = round(area_busqueda, 2)
        resultado["cgt_hit_score_pct"]  = round(cgt_hs, 2)
    else:
        # Sin anchor real: mostrar área del top 10%
        umbral = 90.0
        n_top = int((prob_matrix >= umbral).sum())
        area_top = n_top * area_celda / 1e6
        resultado["area_busqueda_km2"]  = round(area_top, 2)
        resultado["cgt_hit_score_pct"]  = round((area_top / area_caza_total) * 100.0, 2)

    QgsMessageLog.logMessage(
        f"[RossmoCBA] CGT Hit Score: {resultado['cgt_hit_score_pct']:.2f}% | "
        f"Área búsqueda: {resultado['area_busqueda_km2']} km²",
        "RossmoCBA", Qgis.Info
    )
    return resultado


def pipeline_rossmo(gdf_crimenes: gpd.GeoDataFrame,
                    B: float = 500.0,
                    f: float = 1.0,
                    g: float = 1.0,
                    k: float = 1.0,
                    paso: float = 100.0,
                    anchor_real_wgs84: tuple = None) -> dict:
    """
    Pipeline completo del CGT de Rossmo.

    Parámetros:
        gdf_crimenes      : GeoDataFrame de puntos (crímenes del ofensor)
        B                 : radio del buffer en metros
        f, g              : exponentes de la fórmula
        k                 : coeficiente
        paso              : resolución de la grilla en metros
        anchor_real_wgs84 : (lon, lat) del anchor real conocido (opcional)

    Retorna dict con:
        prob_matrix, grid_x, grid_y, bbox, metricas, crimen_coords
    """
    if len(gdf_crimenes) < 3:
        raise ValueError(
            f"El perfilamiento de Rossmo requiere al menos 3 sitios de crimen. "
            f"Se proveyeron {len(gdf_crimenes)}."
        )

    # 1. Preparar coordenadas en metros
    crimen_coords = preparar_crimen_coords(gdf_crimenes)

    # 2. Construir grilla
    grid_x, grid_y, bbox = construir_grilla(crimen_coords, paso=paso)

    QgsMessageLog.logMessage(
        f"[RossmoCBA] Grilla: {len(grid_x)}×{len(grid_y)} = "
        f"{len(grid_x)*len(grid_y):,} celdas | "
        f"Crímenes: {len(crimen_coords)} | B={B}m f={f} g={g}",
        "RossmoCBA", Qgis.Info
    )

    # 3. Calcular superficie de probabilidad
    prob_matrix = calcular_rossmo(crimen_coords, grid_x, grid_y,
                                   B=B, f=f, g=g, k=k)

    # 4. Convertir anchor real a métrico si se proveyó
    anchor_real_m = None
    if anchor_real_wgs84 is not None:
        transformer = Transformer.from_crs(CRS_WGS84, CRS_METRICA, always_xy=True)
        ax, ay = transformer.transform(anchor_real_wgs84[0], anchor_real_wgs84[1])
        anchor_real_m = (ax, ay)

    # 5. Métricas
    metricas = calcular_cgt_hit_score(
        crimen_coords, prob_matrix, grid_x, grid_y,
        anchor_real=anchor_real_m
    )
    metricas["B"] = B
    metricas["f"] = f
    metricas["g"] = g
    metricas["k"] = k
    metricas["paso_m"] = paso

    return {
        "prob_matrix":    prob_matrix,
        "grid_x":         grid_x,
        "grid_y":         grid_y,
        "bbox":           bbox,
        "metricas":       metricas,
        "crimen_coords":  crimen_coords,
    }


def interpretar_resultado(metricas: dict) -> str:
    """Genera texto de interpretación para el panel."""
    lineas = [
        "═" * 48,
        "  RESULTADO — PERFILAMIENTO GEOGRÁFICO (CGT)",
        "  Modelo de Kim Rossmo (2000)",
        "═" * 48,
        f"  Crímenes analizados:  {metricas['n_crimenes']}",
        f"  Buffer B:             {metricas['B']:.0f} m",
        f"  Exponente f:          {metricas['f']}",
        f"  Exponente g:          {metricas['g']}",
        f"  Coeficiente k:        {metricas['k']}",
        f"  Resolución grilla:    {metricas['paso_m']:.0f} m",
        "─" * 48,
        "  ANCHOR POINT ESTIMADO (máxima probabilidad):",
        f"  Latitud:   {metricas['anchor_lat']}",
        f"  Longitud:  {metricas['anchor_lon']}",
        "─" * 48,
        f"  Área de caza total:   {metricas['area_caza_km2']} km²",
        f"  Área de búsqueda:     {metricas['area_busqueda_km2']} km²",
        f"  CGT Hit Score:        {metricas['cgt_hit_score_pct']}%",
        "─" * 48,
    ]

    if metricas.get("distancia_al_max_m") is not None:
        lineas.append(
            f"  Dist. anchor real → predicho: "
            f"{metricas['distancia_al_max_m']:.0f} m"
        )

    cgt = metricas['cgt_hit_score_pct']
    if cgt is not None:
        if cgt <= 5:
            interp = "EXCELENTE: el modelo reduce la búsqueda al\n  " \
                     f"{cgt:.1f}% del área de caza."
        elif cgt <= 15:
            interp = f"BUENO: la búsqueda se concentra en el {cgt:.1f}%\n  " \
                     "del área de caza."
        elif cgt <= 30:
            interp = f"MODERADO: {cgt:.1f}% del área debe buscarse.\n  " \
                     "Ajustar parámetros B, f, g puede mejorar el resultado."
        else:
            interp = f"LIMITADO: el modelo requiere {cgt:.1f}% del área.\n  " \
                     "Revisar parámetros o cantidad de crímenes."
        lineas.append(f"  INTERPRETACIÓN: {interp}")

    lineas.append("═" * 48)
    return "\n".join(lineas)
