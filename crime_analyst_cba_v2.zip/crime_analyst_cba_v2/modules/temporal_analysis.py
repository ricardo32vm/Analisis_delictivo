# -*- coding: utf-8 -*-
"""
modules/temporal_analysis.py

Análisis temporal de delitos:
  - Tendencia anual
  - Estacionalidad mensual
  - Distribución por día de la semana
  - Distribución horaria (mapa de calor hora x día)
  - Comparación entre tipos de delito

Retorna siempre estructuras de datos listas para graficar con matplotlib.
"""

import pandas as pd
import numpy as np
import geopandas as gpd
from qgis.core import QgsMessageLog, Qgis


DIAS = ["Lunes", "Martes", "Miércoles", "Jueves",
        "Viernes", "Sábado", "Domingo"]

MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
         "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]


def _check_temporal(gdf: gpd.GeoDataFrame):
    if "fecha_hora" not in gdf.columns or gdf["fecha_hora"].isna().all():
        raise ValueError(
            "El dataset no tiene columna de fecha/hora válida. "
            "Verificá que el archivo incluya una columna de fecha."
        )


def tendencia_anual(gdf: gpd.GeoDataFrame,
                    tipo_delito: str = None,
                    distrito: str = None) -> dict:
    """
    Cuenta hechos por año. Retorna datos para gráfico de barras/línea.

    Retorna:
      {'anios': [...], 'conteos': [...], 'variacion_pct': [...]}
    """
    _check_temporal(gdf)
    data = gdf.copy()
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]
    if distrito and "distrito" in data.columns:
        data = data[data["distrito"] == distrito]

    conteo = data.groupby("anio").size().reset_index(name="conteo")
    conteo = conteo.sort_values("anio")

    variacion = [None]
    for i in range(1, len(conteo)):
        prev = conteo.iloc[i-1]["conteo"]
        curr = conteo.iloc[i]["conteo"]
        variacion.append(round((curr - prev) / prev * 100, 1) if prev > 0 else 0)

    return {
        "anios":         conteo["anio"].tolist(),
        "conteos":       conteo["conteo"].tolist(),
        "variacion_pct": variacion,
        "total":         int(conteo["conteo"].sum()),
        "promedio_anual": round(conteo["conteo"].mean(), 1),
    }


def estacionalidad_mensual(gdf: gpd.GeoDataFrame,
                            tipo_delito: str = None,
                            normalizar: bool = True) -> dict:
    """
    Promedio de hechos por mes del año (agrupado sobre todos los años).
    Normalizar=True devuelve valores relativos al promedio (índice estacional).

    Retorna:
      {'meses': [...], 'valores': [...], 'mes_pico': str, 'mes_valle': str}
    """
    _check_temporal(gdf)
    data = gdf.copy()
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]

    conteo = data.groupby(["anio", "mes"]).size().reset_index(name="conteo")
    promedio = conteo.groupby("mes")["conteo"].mean().reset_index()
    promedio = promedio.sort_values("mes")

    valores = promedio["conteo"].tolist()
    if normalizar and np.mean(valores) > 0:
        mean_val = np.mean(valores)
        valores_norm = [round(v / mean_val, 3) for v in valores]
    else:
        valores_norm = [round(v, 1) for v in valores]

    meses_presentes = promedio["mes"].tolist()
    etiquetas = [MESES[m-1] for m in meses_presentes]

    idx_pico  = int(np.argmax(valores_norm))
    idx_valle = int(np.argmin(valores_norm))

    return {
        "meses":      etiquetas,
        "valores":    valores_norm,
        "mes_pico":   etiquetas[idx_pico],
        "mes_valle":  etiquetas[idx_valle],
        "valor_pico": valores_norm[idx_pico],
        "normalizado": normalizar,
    }


def distribucion_diaria(gdf: gpd.GeoDataFrame,
                         tipo_delito: str = None) -> dict:
    """
    Distribución de hechos por día de la semana.

    Retorna:
      {'dias': [...], 'conteos': [...], 'dia_pico': str}
    """
    _check_temporal(gdf)
    data = gdf.copy()
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]

    conteo = data.groupby("dia_semana").size().reindex(range(7), fill_value=0)

    return {
        "dias":      DIAS,
        "conteos":   conteo.tolist(),
        "dia_pico":  DIAS[int(conteo.idxmax())],
    }


def mapa_calor_hora_dia(gdf: gpd.GeoDataFrame,
                         tipo_delito: str = None) -> dict:
    """
    Matriz hora (0-23) × día de la semana (0-6).
    Ideal para visualizar como heatmap 2D.

    Retorna:
      {'matrix': array 24x7, 'dias': [...], 'horas': [...]}
    """
    _check_temporal(gdf)
    if "hora" not in gdf.columns:
        raise ValueError("Sin datos de hora en el dataset.")

    data = gdf.copy()
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]

    matrix = np.zeros((24, 7), dtype=int)
    for _, row in data.iterrows():
        h = int(row.get("hora", 0))
        d = int(row.get("dia_semana", 0))
        if 0 <= h < 24 and 0 <= d < 7:
            matrix[h][d] += 1

    return {
        "matrix": matrix.tolist(),
        "dias":   DIAS,
        "horas":  list(range(24)),
        "max_val": int(matrix.max()),
    }


def comparar_tipos(gdf: gpd.GeoDataFrame,
                   top_n: int = 6) -> dict:
    """
    Tendencia anual de los top_n tipos de delito más frecuentes.
    Retorna datos para gráfico de líneas múltiple.

    Retorna:
      {'anios': [...], 'series': [{'tipo': str, 'valores': [...]}, ...]}
    """
    _check_temporal(gdf)
    if "tipo_delito" not in gdf.columns:
        raise ValueError("Sin columna tipo_delito en el dataset.")

    top_tipos = gdf["tipo_delito"].value_counts().head(top_n).index.tolist()
    data = gdf[gdf["tipo_delito"].isin(top_tipos)].copy()

    pivot = (data.groupby(["anio", "tipo_delito"])
                 .size()
                 .unstack(fill_value=0)
                 .reindex(columns=top_tipos, fill_value=0))

    anios = sorted(pivot.index.tolist())

    series = []
    for tipo in top_tipos:
        if tipo in pivot.columns:
            series.append({
                "tipo":    tipo,
                "valores": pivot.loc[anios, tipo].tolist() if anios else [],
            })

    return {
        "anios":  anios,
        "series": series,
    }


def resumen_para_llm(gdf: gpd.GeoDataFrame,
                     tipo_delito: str = None,
                     distrito: str = None) -> str:
    """
    Genera un texto estructurado con los principales hallazgos temporales
    para incluir en el prompt del LLM.
    """
    lineas = []

    try:
        tend = tendencia_anual(gdf, tipo_delito, distrito)
        lineas.append(f"TENDENCIA ANUAL:")
        for a, c, v in zip(tend["anios"], tend["conteos"], tend["variacion_pct"]):
            var_str = f" ({'+' if v and v>0 else ''}{v}%)" if v is not None else ""
            lineas.append(f"  {a}: {c} hechos{var_str}")
        lineas.append(f"  Promedio anual: {tend['promedio_anual']} hechos")
    except Exception:
        pass

    try:
        est = estacionalidad_mensual(gdf, tipo_delito)
        lineas.append(f"\nESTACIONALIDAD:")
        lineas.append(f"  Mes de mayor actividad: {est['mes_pico']} (índice {est['valor_pico']:.2f})")
        lineas.append(f"  Mes de menor actividad: {est['mes_valle']}")
    except Exception:
        pass

    try:
        dist = distribucion_diaria(gdf, tipo_delito)
        lineas.append(f"\nDISTRIBUCIÓN SEMANAL:")
        lineas.append(f"  Día de mayor concentración: {dist['dia_pico']}")
        for dia, cnt in zip(dist["dias"], dist["conteos"]):
            lineas.append(f"  {dia}: {cnt} hechos")
    except Exception:
        pass

    return "\n".join(lineas)
