# -*- coding: utf-8 -*-
"""
modules/layer_builder.py

Genera las capas QGIS del análisis Rossmo CGT:
  1. Raster de probabilidad (superficie de Jeopardy)
  2. Punto de anchor estimado (máxima probabilidad)
  3. Puntos de crimen originales
  4. Punto anchor real (si se proveyó)
"""

import numpy as np
import tempfile
import geopandas as gpd
from pyproj import Transformer

from qgis.core import (
    QgsProject, QgsRasterLayer, QgsVectorLayer,
    QgsFeature, QgsGeometry, QgsPointXY,
    QgsField, QgsFields, QgsColorRampShader,
    QgsRasterShader, QgsSingleBandPseudoColorRenderer,
    QgsMarkerSymbol, QgsCategorizedSymbolRenderer,
    QgsRendererCategory, QgsMessageLog, Qgis
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import QVariant

CRS_WGS84  = "EPSG:4326"
CRS_METRICA = "EPSG:5345"

try:
    import rasterio
    from rasterio.transform import from_bounds
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False


def crear_capa_probabilidad(resultado: dict,
                             nombre: str = "Rossmo — Superficie de probabilidad") -> QgsRasterLayer:
    """
    Genera el raster GeoTIFF con la superficie de probabilidad CGT
    y lo agrega al mapa QGIS con rampa de color tipo heatmap.
    """
    if not RASTERIO_OK:
        raise ImportError(
            "rasterio no está instalado.\n"
            "Instalá con: pip install rasterio --user"
        )

    prob  = resultado["prob_matrix"]
    gx    = resultado["grid_x"]
    gy    = resultado["grid_y"]
    xmin, xmax, ymin, ymax = resultado["bbox"]

    # Exportar como GeoTIFF en CRS métrico
    tif_path = tempfile.mktemp(suffix="_rossmo.tif")
    transform = from_bounds(xmin, ymin, xmax, ymax, len(gx), len(gy))

    with rasterio.open(
        tif_path, "w",
        driver="GTiff",
        height=len(gy),
        width=len(gx),
        count=1,
        dtype=prob.dtype,
        crs=CRS_METRICA,
        transform=transform,
    ) as dst:
        dst.write(prob[::-1], 1)   # voltear eje Y

    layer = QgsRasterLayer(tif_path, nombre)
    if not layer.isValid():
        raise RuntimeError(f"No se pudo cargar el raster: {tif_path}")

    _aplicar_rampa_rossmo(layer)
    QgsProject.instance().addMapLayer(layer)

    QgsMessageLog.logMessage(
        f"[RossmoCBA] Raster de probabilidad creado.",
        "RossmoCBA", Qgis.Info
    )
    return layer


def _aplicar_rampa_rossmo(layer: QgsRasterLayer):
    """Rampa tipo Jeopardy Surface: negro → rojo → amarillo → blanco."""
    from qgis.core import QgsRasterShader, QgsColorRampShader, QgsSingleBandPseudoColorRenderer

    shader = QgsRasterShader()
    cr     = QgsColorRampShader()
    cr.setColorRampType(QgsColorRampShader.Interpolated)

    cr.setColorRampItemList([
        QgsColorRampShader.ColorRampItem(0,   QColor(0,   0,   0, 0),   "0%"),
        QgsColorRampShader.ColorRampItem(20,  QColor(20,  0, 180, 80),  "20%"),
        QgsColorRampShader.ColorRampItem(40,  QColor(0,  80, 255, 120), "40%"),
        QgsColorRampShader.ColorRampItem(60,  QColor(0, 200,  50, 160), "60%"),
        QgsColorRampShader.ColorRampItem(75,  QColor(255, 200, 0, 190), "75%"),
        QgsColorRampShader.ColorRampItem(90,  QColor(255,  80, 0, 220), "90%"),
        QgsColorRampShader.ColorRampItem(100, QColor(255, 255, 255, 255),"100%"),
    ])

    shader.setRasterShaderFunction(cr)
    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


def crear_capa_anchor(metricas: dict,
                      nombre: str = "Rossmo — Anchor point estimado") -> QgsVectorLayer:
    """
    Crea un punto marcando el anchor point estimado (máxima probabilidad).
    """
    uri   = f"Point?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    prov  = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("tipo",       QVariant.String))
    fields.append(QgsField("prob_max",   QVariant.Double))
    fields.append(QgsField("latitud",    QVariant.Double))
    fields.append(QgsField("longitud",   QVariant.Double))
    prov.addAttributes(fields)
    layer.updateFields()

    lon = metricas.get("anchor_lon")
    lat = metricas.get("anchor_lat")
    if lon and lat:
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        feat.setAttributes(["Anchor estimado", 100.0, lat, lon])
        prov.addFeatures([feat])
        layer.updateExtents()

    # Simbología: estrella roja
    symbol = QgsMarkerSymbol.createSimple({
        "name":          "star",
        "color":         "#CC0000",
        "size":          "8",
        "outline_color": "#FFFFFF",
        "outline_width": "0.8",
    })
    layer.renderer().setSymbol(symbol)

    QgsProject.instance().addMapLayer(layer)
    return layer


def crear_capa_crimenes(gdf: gpd.GeoDataFrame,
                         nombre: str = "Rossmo — Sitios de crimen") -> QgsVectorLayer:
    """
    Crea una capa de puntos con los sitios de crimen usados en el análisis.
    """
    uri   = f"Point?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    prov  = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("n",           QVariant.Int))
    fields.append(QgsField("tipo_delito", QVariant.String))
    fields.append(QgsField("fecha",       QVariant.String))
    prov.addAttributes(fields)
    layer.updateFields()

    features = []
    for i, row in enumerate(gdf.itertuples()):
        feat = QgsFeature()
        lon = row.geometry.x
        lat = row.geometry.y
        feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        feat.setAttributes([
            i + 1,
            str(getattr(row, "tipo_delito", "")),
            str(getattr(row, "fecha_hora", "")),
        ])
        features.append(feat)

    prov.addFeatures(features)
    layer.updateExtents()

    symbol = QgsMarkerSymbol.createSimple({
        "name":          "circle",
        "color":         "#FF4500",
        "size":          "5",
        "outline_color": "#FFFFFF",
        "outline_width": "0.5",
    })
    layer.renderer().setSymbol(symbol)

    QgsProject.instance().addMapLayer(layer)
    return layer


def crear_capa_anchor_real(lon: float, lat: float,
                            nombre: str = "Rossmo — Anchor real") -> QgsVectorLayer:
    """
    Crea un punto con el anchor real conocido (para evaluación del modelo).
    """
    uri   = f"Point?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    prov  = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("tipo",    QVariant.String))
    fields.append(QgsField("latitud", QVariant.Double))
    fields.append(QgsField("longitud",QVariant.Double))
    prov.addAttributes(fields)
    layer.updateFields()

    feat = QgsFeature()
    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
    feat.setAttributes(["Anchor real (conocido)", lat, lon])
    prov.addFeatures([feat])
    layer.updateExtents()

    symbol = QgsMarkerSymbol.createSimple({
        "name":          "cross2",
        "color":         "#00AA00",
        "size":          "10",
        "outline_color": "#FFFFFF",
        "outline_width": "1.0",
    })
    layer.renderer().setSymbol(symbol)

    QgsProject.instance().addMapLayer(layer)
    return layer


def generar_todas_las_capas(resultado: dict,
                              gdf_crimenes: gpd.GeoDataFrame,
                              metricas: dict,
                              anchor_real_wgs84: tuple = None) -> dict:
    """
    Genera las 3–4 capas del análisis Rossmo de una sola vez.
    Orden de inserción: raster primero (fondo), puntos arriba.
    """
    capas = {}

    capas["probabilidad"] = crear_capa_probabilidad(resultado)
    capas["crimenes"]     = crear_capa_crimenes(gdf_crimenes)
    capas["anchor"]       = crear_capa_anchor(metricas)

    if anchor_real_wgs84 is not None:
        lon, lat = anchor_real_wgs84
        capas["anchor_real"] = crear_capa_anchor_real(lon, lat)

    return capas
