# -*- coding: utf-8 -*-
"""
modules/layer_builder.py

Genera las 4 capas de visualización near repeat en QGIS:
  1. Puntos coloreados por nivel de riesgo NR
  2. Buffers de zona de riesgo alrededor de cada punto
  3. Líneas entre pares near repeat identificados
  4. Heatmap (capa de calor) de zonas NR
"""

import numpy as np
import pandas as pd
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsPointXY, QgsField, QgsFields, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsRasterLayer,
    QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer,
    QgsGraduatedSymbolRenderer, QgsRendererRange,
    QgsSimpleMarkerSymbolLayer, QgsSimpleFillSymbolLayer,
    QgsSimpleLineSymbolLayer, QgsFillSymbol, QgsLineSymbol,
    QgsMarkerSymbol, QgsHeatmapRenderer, QgsColorRampShader,
    QgsRasterShader, QgsSingleBandPseudoColorRenderer,
    QgsGradientColorRamp, QgsMessageLog, Qgis
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import QVariant

CRS_WGS84 = "EPSG:4326"

# Colores por nivel de riesgo
COLORES_RIESGO = {
    0: QColor("#AAAAAA"),   # Sin riesgo — gris
    1: QColor("#FFD700"),   # Bajo — amarillo
    2: QColor("#FF8C00"),   # Medio — naranja
    3: QColor("#CC0000"),   # Alto — rojo
}
LABELS_RIESGO = {
    0: "Sin riesgo NR",
    1: "Riesgo bajo (1 par)",
    2: "Riesgo medio (2-3 pares)",
    3: "Riesgo alto (4+ pares)",
}


# ---------------------------------------------------------------------------
# CAPA 1: Puntos coloreados por nivel de riesgo
# ---------------------------------------------------------------------------
def crear_capa_puntos(df_riesgo: pd.DataFrame,
                      nombre: str = "NR — Puntos de riesgo") -> QgsVectorLayer:
    """
    Crea una capa de puntos con los eventos coloreados según
    su nivel de riesgo near repeat.
    """
    uri = f"Point?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    provider = layer.dataProvider()

    # Campos
    fields = QgsFields()
    fields.append(QgsField("id",           QVariant.Int))
    fields.append(QgsField("nivel_riesgo", QVariant.Int))
    fields.append(QgsField("nivel_texto",  QVariant.String))
    fields.append(QgsField("conteo_nr",    QVariant.Int))
    fields.append(QgsField("tipo_delito",  QVariant.String))
    fields.append(QgsField("distrito",     QVariant.String))
    fields.append(QgsField("fecha_hora",   QVariant.String))
    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    for _, row in df_riesgo.iterrows():
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(
            QgsPointXY(float(row["lon"]), float(row["lat"]))
        ))
        feat.setAttributes([
            int(row["id"]),
            int(row["nivel_riesgo"]),
            str(row["nivel_texto"]),
            int(row["conteo_nr"]),
            str(row.get("tipo_delito", "")),
            str(row.get("distrito", "")),
            str(row.get("fecha_hora", "")),
        ])
        features.append(feat)

    provider.addFeatures(features)
    layer.updateExtents()

    # Simbología categorizada por nivel de riesgo
    categorias = []
    for nivel, color in COLORES_RIESGO.items():
        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle",
            "color": color.name(),
            "outline_color": "#333333",
            "outline_width": "0.3",
            "size": "3" if nivel == 0 else str(3 + nivel),
        })
        cat = QgsRendererCategory(nivel, symbol, LABELS_RIESGO[nivel])
        categorias.append(cat)

    renderer = QgsCategorizedSymbolRenderer("nivel_riesgo", categorias)
    layer.setRenderer(renderer)

    QgsProject.instance().addMapLayer(layer)
    QgsMessageLog.logMessage(
        f"[NearRepeat] Capa de puntos creada: {len(features)} eventos.",
        "NearRepeatCBA", Qgis.Info
    )
    return layer


# ---------------------------------------------------------------------------
# CAPA 2: Buffers de zona de riesgo
# ---------------------------------------------------------------------------
def crear_capa_buffers(df_riesgo: pd.DataFrame,
                       dist_umbral: float,
                       nombre: str = "NR — Buffers de riesgo") -> QgsVectorLayer:
    """
    Crea buffers circulares alrededor de los puntos con riesgo NR > 0.
    El radio del buffer = umbral espacial del Knox test.
    La transparencia varía según el nivel de riesgo.
    """
    # Solo puntos con riesgo NR
    df_con_riesgo = df_riesgo[df_riesgo["nivel_riesgo"] > 0].copy()

    if len(df_con_riesgo) == 0:
        QgsMessageLog.logMessage(
            "[NearRepeat] Sin puntos con riesgo NR para generar buffers.",
            "NearRepeatCBA", Qgis.Warning
        )
        return None

    # Proyectar a metros para el buffer
    import geopandas as gpd
    from shapely.geometry import Point

    gdf_proy = gpd.GeoDataFrame(
        df_con_riesgo,
        geometry=gpd.points_from_xy(df_con_riesgo["lon"], df_con_riesgo["lat"]),
        crs="EPSG:4326"
    ).to_crs("EPSG:5345")

    # Buffer en metros
    gdf_proy["geometry"] = gdf_proy.geometry.buffer(dist_umbral)

    # Reproyectar a WGS84
    gdf_buf = gdf_proy.to_crs("EPSG:4326")

    uri = f"Polygon?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    provider = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("id",           QVariant.Int))
    fields.append(QgsField("nivel_riesgo", QVariant.Int))
    fields.append(QgsField("nivel_texto",  QVariant.String))
    fields.append(QgsField("conteo_nr",    QVariant.Int))
    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    for _, row in gdf_buf.iterrows():
        feat = QgsFeature()
        geom_wkt = row.geometry.wkt
        feat.setGeometry(QgsGeometry.fromWkt(geom_wkt))
        feat.setAttributes([
            int(row["id"]),
            int(row["nivel_riesgo"]),
            str(row["nivel_texto"]),
            int(row["conteo_nr"]),
        ])
        features.append(feat)

    provider.addFeatures(features)
    layer.updateExtents()

    # Simbología: polígono con relleno semitransparente por nivel
    categorias = []
    transparencias = {1: 180, 2: 150, 3: 120}  # alfa (0=transparente, 255=opaco)
    for nivel in [1, 2, 3]:
        color = QColor(COLORES_RIESGO[nivel])
        color.setAlpha(transparencias[nivel])
        borde = QColor(COLORES_RIESGO[nivel])
        borde.setAlpha(220)
        symbol = QgsFillSymbol.createSimple({
            "color": color.name(QColor.HexArgb),
            "outline_color": borde.name(),
            "outline_width": "0.4",
            "style": "solid",
        })
        cat = QgsRendererCategory(nivel, symbol, LABELS_RIESGO[nivel])
        categorias.append(cat)

    renderer = QgsCategorizedSymbolRenderer("nivel_riesgo", categorias)
    layer.setRenderer(renderer)
    layer.setOpacity(0.6)

    QgsProject.instance().addMapLayer(layer)
    QgsMessageLog.logMessage(
        f"[NearRepeat] Capa de buffers creada: {len(features)} zonas.",
        "NearRepeatCBA", Qgis.Info
    )
    return layer


# ---------------------------------------------------------------------------
# CAPA 3: Líneas entre pares near repeat
# ---------------------------------------------------------------------------
def crear_capa_lineas(df_pares: pd.DataFrame,
                      nombre: str = "NR — Pares near repeat") -> QgsVectorLayer:
    """
    Crea líneas conectando cada par de eventos near repeat.
    Coloreadas por diferencia temporal (más reciente = más intenso).
    """
    if len(df_pares) == 0:
        return None

    uri = f"LineString?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    provider = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("id_origen",   QVariant.Int))
    fields.append(QgsField("id_destino",  QVariant.Int))
    fields.append(QgsField("distancia_m", QVariant.Double))
    fields.append(QgsField("diff_dias",   QVariant.Double))
    fields.append(QgsField("tipo_orig",   QVariant.String))
    fields.append(QgsField("tipo_dest",   QVariant.String))
    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    for _, row in df_pares.iterrows():
        feat = QgsFeature()
        p1 = QgsPointXY(float(row["lon_orig"]), float(row["lat_orig"]))
        p2 = QgsPointXY(float(row["lon_dest"]), float(row["lat_dest"]))
        feat.setGeometry(QgsGeometry.fromPolylineXY([p1, p2]))
        feat.setAttributes([
            int(row["id_origen"]),
            int(row["id_destino"]),
            float(row["distancia_m"]),
            float(row["diff_dias"]),
            str(row.get("tipo_orig", "")),
            str(row.get("tipo_dest", "")),
        ])
        features.append(feat)

    provider.addFeatures(features)
    layer.updateExtents()

    # Simbología graduada por diferencia temporal
    max_dias = float(df_pares["diff_dias"].max()) if len(df_pares) > 0 else 14.0
    mid_dias = max_dias / 2

    rangos = [
        QgsRendererRange(0, mid_dias,
            QgsLineSymbol.createSimple({"color": "#CC0000", "width": "0.6"}),
            f"0 — {mid_dias:.0f} días (más reciente)"),
        QgsRendererRange(mid_dias, max_dias,
            QgsLineSymbol.createSimple({"color": "#FF8C00", "width": "0.4"}),
            f"{mid_dias:.0f} — {max_dias:.0f} días"),
    ]

    renderer = QgsGraduatedSymbolRenderer("diff_dias", rangos)
    layer.setRenderer(renderer)
    layer.setOpacity(0.75)

    QgsProject.instance().addMapLayer(layer)
    QgsMessageLog.logMessage(
        f"[NearRepeat] Capa de pares creada: {len(features)} líneas.",
        "NearRepeatCBA", Qgis.Info
    )
    return layer


# ---------------------------------------------------------------------------
# CAPA 4: Heatmap de concentración NR
# ---------------------------------------------------------------------------
def crear_capa_heatmap(df_riesgo: pd.DataFrame,
                       nombre: str = "NR — Heatmap") -> QgsVectorLayer:
    """
    Crea una capa de puntos con el renderer QgsHeatmapRenderer de QGIS,
    ponderada por nivel de riesgo. QGIS renderiza el heatmap en tiempo real.
    Solo incluye puntos con riesgo NR > 0.
    """
    df_nr = df_riesgo[df_riesgo["nivel_riesgo"] > 0].copy()

    if len(df_nr) == 0:
        return None

    uri = f"Point?crs={CRS_WGS84}"
    layer = QgsVectorLayer(uri, nombre, "memory")
    provider = layer.dataProvider()

    fields = QgsFields()
    fields.append(QgsField("peso", QVariant.Double))
    provider.addAttributes(fields)
    layer.updateFields()

    features = []
    for _, row in df_nr.iterrows():
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(
            QgsPointXY(float(row["lon"]), float(row["lat"]))
        ))
        # Peso proporcional al nivel de riesgo
        feat.setAttributes([float(row["nivel_riesgo"])])
        features.append(feat)

    provider.addFeatures(features)
    layer.updateExtents()

    # QgsHeatmapRenderer nativo de QGIS
    renderer = QgsHeatmapRenderer()
    renderer.setRadius(30)           # radio en unidades del mapa
    renderer.setRadiusUnit(1)        # 1 = unidades del mapa (grados aprox)
    renderer.setWeightExpression('"peso"')

    # Rampa de color: transparente → amarillo → rojo
    ramp = QgsGradientColorRamp(
        QColor(255, 255, 0, 0),    # inicio transparente
        QColor(204, 0, 0, 255),    # fin rojo opaco
    )
    renderer.setColorRamp(ramp)
    layer.setRenderer(renderer)

    QgsProject.instance().addMapLayer(layer)
    QgsMessageLog.logMessage(
        f"[NearRepeat] Heatmap NR creado: {len(features)} puntos.",
        "NearRepeatCBA", Qgis.Info
    )
    return layer


# ---------------------------------------------------------------------------
# Función principal: genera las 4 capas de una vez
# ---------------------------------------------------------------------------
def generar_todas_las_capas(resultado: dict,
                             tipo_delito: str = None,
                             capas_activas: dict = None) -> dict:
    """
    Genera las 4 capas de visualización.

    Parámetros:
      - resultado: dict devuelto por knox_montecarlo()
      - tipo_delito: string para incluir en el nombre de las capas
      - capas_activas: dict con flags booleanos
        {'puntos': True, 'buffers': True, 'lineas': True, 'heatmap': True}

    Retorna dict con las capas creadas.
    """
    from .knox_test import calcular_riesgo_por_punto, extraer_pares_nr

    if capas_activas is None:
        capas_activas = {"puntos": True, "buffers": True,
                         "lineas": True, "heatmap": True}

    sufijo = f" — {tipo_delito}" if tipo_delito else ""
    dist_u = resultado["dist_umbral"]

    df_riesgo = calcular_riesgo_por_punto(resultado)
    df_pares  = extraer_pares_nr(resultado)

    capas = {}

    # Orden de creación: heatmap primero (queda abajo), puntos al tope
    if capas_activas.get("heatmap", True):
        capas["heatmap"] = crear_capa_heatmap(
            df_riesgo, f"NR — Heatmap{sufijo}"
        )

    if capas_activas.get("buffers", True):
        capas["buffers"] = crear_capa_buffers(
            df_riesgo, dist_u, f"NR — Buffers{sufijo}"
        )

    if capas_activas.get("lineas", True):
        capas["lineas"] = crear_capa_lineas(
            df_pares, f"NR — Pares{sufijo}"
        )

    if capas_activas.get("puntos", True):
        capas["puntos"] = crear_capa_puntos(
            df_riesgo, f"NR — Puntos{sufijo}"
        )

    # Resumen de puntos por nivel
    resumen = df_riesgo["nivel_riesgo"].value_counts().sort_index()
    QgsMessageLog.logMessage(
        f"[NearRepeat] Distribución de riesgo: {resumen.to_dict()}",
        "NearRepeatCBA", Qgis.Info
    )

    return {
        "capas":     capas,
        "df_riesgo": df_riesgo,
        "df_pares":  df_pares,
        "resumen_riesgo": resumen.to_dict(),
    }
