# -*- coding: utf-8 -*-
"""
ui/dialog_main.py

Interfaz del plugin Rossmo CBA.
Tres pestañas:
  1. Datos y parámetros
  2. Resultado y mapa
  3. Evaluación del modelo (CGT Hit Score)
"""

import os
import traceback

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QPushButton, QLabel, QComboBox, QDoubleSpinBox, QSpinBox,
    QTextEdit, QProgressBar, QGroupBox, QFormLayout,
    QSizePolicy, QMessageBox, QFileDialog, QCheckBox, QLineEdit
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.core import (
    QgsProject, QgsMapLayerType, QgsWkbTypes,
    QgsMessageLog, Qgis
)

try:
    import matplotlib
    matplotlib.use("Qt5Agg")
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    import numpy as np
    MATPLOTLIB_OK = True
except ImportError:
    MATPLOTLIB_OK = False


class RossmoWorker(QThread):
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)

    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            self.finished.emit(self.func(*self.args, **self.kwargs))
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


class RossmoDialog(QDialog):

    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.iface     = iface
        self.gdf       = None
        self.resultado = None
        self.metricas  = None
        self.setWindowTitle("Rossmo CBA — Perfilamiento Geográfico Criminal")
        self.setMinimumSize(800, 640)
        self._build_ui()
        self._refrescar_capas()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        hdr = QLabel("Rossmo CBA  ·  Criminal Geographic Targeting  ·  UNVM")
        f = QFont(); f.setBold(True); f.setPointSize(11)
        hdr.setFont(f); hdr.setAlignment(Qt.AlignCenter)
        layout.addWidget(hdr)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_parametros(), "1 · Datos y parámetros")
        self.tabs.addTab(self._tab_resultado(),  "2 · Resultado")
        self.tabs.addTab(self._tab_evaluacion(), "3 · Evaluación del modelo")
        layout.addWidget(self.tabs)

        self.status = QLabel("Cargá una capa de puntos y configurá los parámetros.")
        self.status.setStyleSheet("color: gray; font-size: 11px;")
        layout.addWidget(self.status)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.close)
        layout.addWidget(btn_cerrar)

    # ------------------------------------------------------------------
    # TAB 1: Datos y parámetros
    # ------------------------------------------------------------------
    def _tab_parametros(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        # Fuente de datos
        grp_datos = QGroupBox("Fuente de datos — sitios de crimen")
        form_datos = QFormLayout(grp_datos)

        self.cmb_capa = QComboBox()
        btn_r = QPushButton("↻")
        btn_r.setMaximumWidth(30)
        btn_r.clicked.connect(self._refrescar_capas)
        row_c = QHBoxLayout()
        row_c.addWidget(self.cmb_capa)
        row_c.addWidget(btn_r)
        form_datos.addRow("Capa de puntos:", row_c)

        # O cargar CSV
        self.lbl_csv = QLabel("Sin archivo")
        btn_csv = QPushButton("Cargar CSV...")
        btn_csv.clicked.connect(self._cargar_csv)
        row_csv = QHBoxLayout()
        row_csv.addWidget(self.lbl_csv)
        row_csv.addWidget(btn_csv)
        form_datos.addRow("O cargar CSV:", row_csv)

        # Filtros opcionales
        self.cmb_tipo = QComboBox()
        self.cmb_tipo.addItem("Todos los tipos")
        form_datos.addRow("Filtro tipo delito:", self.cmb_tipo)
        layout.addWidget(grp_datos)

        # Parámetros de Rossmo
        grp_p = QGroupBox("Parámetros del modelo CGT (Rossmo)")
        form_p = QFormLayout(grp_p)

        self.spin_B = QDoubleSpinBox()
        self.spin_B.setRange(50, 10000)
        self.spin_B.setValue(500)
        self.spin_B.setSuffix(" m")
        self.spin_B.setToolTip(
            "Radio del buffer B: zona donde el ofensor no actúa\n"
            "para no ser reconocido cerca de su base.\n"
            "Recomendado para ciudad grande: 500–2000 m"
        )

        self.spin_f = QDoubleSpinBox()
        self.spin_f.setRange(0.1, 5.0)
        self.spin_f.setValue(1.0)
        self.spin_f.setSingleStep(0.5)
        self.spin_f.setToolTip("Exponente de decaimiento fuera del buffer")

        self.spin_g = QDoubleSpinBox()
        self.spin_g.setRange(0.1, 5.0)
        self.spin_g.setValue(1.0)
        self.spin_g.setSingleStep(0.5)
        self.spin_g.setToolTip("Exponente de decaimiento dentro del buffer")

        self.spin_k = QDoubleSpinBox()
        self.spin_k.setRange(0.1, 10.0)
        self.spin_k.setValue(1.0)
        self.spin_k.setToolTip("Coeficiente de calibración (normalmente 1.0)")

        self.spin_paso = QSpinBox()
        self.spin_paso.setRange(10, 1000)
        self.spin_paso.setValue(100)
        self.spin_paso.setSuffix(" m")
        self.spin_paso.setToolTip(
            "Resolución de la grilla. Menor = más preciso pero más lento.\n"
            "Para ciudad grande: 100–200 m. Para área pequeña: 50 m."
        )

        form_p.addRow("Buffer B:", self.spin_B)

        row_fg = QHBoxLayout()
        row_fg.addWidget(QLabel("f:"))
        row_fg.addWidget(self.spin_f)
        row_fg.addWidget(QLabel("g:"))
        row_fg.addWidget(self.spin_g)
        form_p.addRow("Exponentes:", row_fg)
        form_p.addRow("Coeficiente k:", self.spin_k)
        form_p.addRow("Resolución grilla:", self.spin_paso)
        layout.addWidget(grp_p)

        # Nota pedagógica
        grp_nota = QGroupBox("Parámetros recomendados (literatura)")
        nota_l = QVBoxLayout(grp_nota)
        lbl_nota = QLabel(
            "Caso Mataviejitas (CDMX): B=500–2000m, f=1.0, g=1.0–2.0\n"
            "Ciudad pequeña/mediana: B=200–500m, f=1.0–1.5, g=1.0–1.5\n"
            "CrimeStat (por defecto): B=0, f=1.2, g=1.2\n\n"
            "Regla general: f < g produce zonas más concentradas.\n"
            "Probá distintas combinaciones y comparar CGT Hit Score."
        )
        lbl_nota.setStyleSheet("font-size: 11px;")
        nota_l.addWidget(lbl_nota)
        layout.addWidget(grp_nota)

        btn_run = QPushButton("Ejecutar análisis CGT de Rossmo")
        btn_run.setStyleSheet("font-weight: bold; padding: 8px;")
        btn_run.clicked.connect(self._run_analisis)
        layout.addWidget(btn_run)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # TAB 2: Resultado
    # ------------------------------------------------------------------
    def _tab_resultado(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        self.txt_resultado = QTextEdit()
        self.txt_resultado.setReadOnly(True)
        self.txt_resultado.setFont(QFont("Courier New", 10))
        self.txt_resultado.setMaximumHeight(260)
        self.txt_resultado.setPlaceholderText(
            "El resultado del análisis CGT aparecerá aquí.\n\n"
            "Capas generadas en el mapa:\n"
            "  ⚪ Superficie de probabilidad (raster Jeopardy)\n"
            "  ★  Anchor point estimado (máxima probabilidad)\n"
            "  🔴 Sitios de crimen analizados"
        )
        layout.addWidget(self.txt_resultado)

        if MATPLOTLIB_OK:
            grp_plot = QGroupBox("Perfil de probabilidad (corte horizontal en Y del anchor)")
            pl = QVBoxLayout(grp_plot)
            self.fig_r = Figure(figsize=(7, 2.5), tight_layout=True)
            self.canvas_r = FigureCanvas(self.fig_r)
            self.canvas_r.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            pl.addWidget(self.canvas_r)
            layout.addWidget(grp_plot)

        # Exportar informe
        btn_exp = QPushButton("Exportar informe a TXT...")
        btn_exp.clicked.connect(self._exportar_informe)
        layout.addWidget(btn_exp)

        return w

    # ------------------------------------------------------------------
    # TAB 3: Evaluación del modelo
    # ------------------------------------------------------------------
    def _tab_evaluacion(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        grp_info = QGroupBox("Evaluación retrospectiva — CGT Hit Score")
        info_l = QVBoxLayout(grp_info)
        lbl = QLabel(
            "Si conocés el anchor real del ofensor (domicilio, base de operaciones)\n"
            "podés calcular el CGT Hit Score oficial de Rossmo:\n\n"
            "  CGT Hit Score = % del área de caza que debe buscarse\n"
            "  para encontrar al ofensor con este modelo.\n\n"
            "Un score bajo (< 10%) indica que el modelo es muy útil.\n"
            "Ejemplo: caso Mataviejitas → CGT HS = 5.27% (Buffer=2000m, f=1, g=2)"
        )
        lbl.setWordWrap(True)
        lbl.setStyleSheet("font-size: 11px;")
        info_l.addWidget(lbl)
        layout.addWidget(grp_info)

        grp_anchor = QGroupBox("Anchor real conocido (opcional)")
        form_a = QFormLayout(grp_anchor)

        self.edit_lat_real = QLineEdit()
        self.edit_lat_real.setPlaceholderText("ej: -31.4135")
        self.edit_lon_real = QLineEdit()
        self.edit_lon_real.setPlaceholderText("ej: -64.1811")

        form_a.addRow("Latitud (WGS84):", self.edit_lat_real)
        form_a.addRow("Longitud (WGS84):", self.edit_lon_real)
        layout.addWidget(grp_anchor)

        btn_eval = QPushButton("Calcular CGT Hit Score con anchor real")
        btn_eval.clicked.connect(self._calcular_con_anchor_real)
        layout.addWidget(btn_eval)

        self.txt_evaluacion = QTextEdit()
        self.txt_evaluacion.setReadOnly(True)
        self.txt_evaluacion.setFont(QFont("Courier New", 10))
        self.txt_evaluacion.setMaximumHeight(200)
        self.txt_evaluacion.setPlaceholderText(
            "El CGT Hit Score con el anchor real aparecerá aquí."
        )
        layout.addWidget(self.txt_evaluacion)

        if MATPLOTLIB_OK:
            grp_bar = QGroupBox("Comparación de parámetros (próximamente)")
            bar_l = QVBoxLayout(grp_bar)
            self.fig_eval = Figure(figsize=(7, 2.5), tight_layout=True)
            self.canvas_eval = FigureCanvas(self.fig_eval)
            self.canvas_eval.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            bar_l.addWidget(self.canvas_eval)
            layout.addWidget(grp_bar)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------
    # Acciones
    # ------------------------------------------------------------------
    def _refrescar_capas(self):
        self.cmb_capa.clear()
        self.cmb_capa.addItem("— Seleccionar capa —")
        for layer in QgsProject.instance().mapLayers().values():
            if (layer.type() == QgsMapLayerType.VectorLayer and
                    layer.geometryType() == QgsWkbTypes.PointGeometry):
                self.cmb_capa.addItem(layer.name(), layer.id())

    def _cargar_csv(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar CSV", "", "CSV (*.csv *.xlsx *.xls)"
        )
        if not fp:
            return
        self.lbl_csv.setText(os.path.basename(fp))
        try:
            import geopandas as gpd
            import pandas as pd
            ext = os.path.splitext(fp)[1].lower()
            if ext in (".xlsx", ".xls"):
                df = pd.read_excel(fp)
            else:
                try:
                    df = pd.read_csv(fp, low_memory=False)
                except UnicodeDecodeError:
                    df = pd.read_csv(fp, encoding="latin-1", low_memory=False)

            # Detectar columnas de coordenadas
            col_lat = next((c for c in df.columns if c.lower() in
                           ["latitud","lat","latitude","y"]), None)
            col_lon = next((c for c in df.columns if c.lower() in
                           ["longitud","lon","longitude","x"]), None)
            if not col_lat or not col_lon:
                raise ValueError("No se encontraron columnas de coordenadas.")

            df[col_lat] = pd.to_numeric(df[col_lat], errors="coerce")
            df[col_lon] = pd.to_numeric(df[col_lon], errors="coerce")
            df = df.dropna(subset=[col_lat, col_lon])

            # Normalizar tipo
            for c in ["prevenible", "tipo_delito", "delito"]:
                if c in df.columns:
                    df["tipo_delito"] = df[c]; break

            self.gdf = gpd.GeoDataFrame(
                df,
                geometry=gpd.points_from_xy(df[col_lon], df[col_lat]),
                crs="EPSG:4326"
            )
            self._poblar_tipos()
            self._set_status(f"CSV cargado: {len(self.gdf):,} registros.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _poblar_tipos(self):
        self.cmb_tipo.clear()
        self.cmb_tipo.addItem("Todos los tipos")
        if self.gdf is not None and "tipo_delito" in self.gdf.columns:
            tipos = sorted(self.gdf["tipo_delito"].dropna().unique().tolist())
            self.cmb_tipo.addItems([str(t) for t in tipos])

    def _get_gdf(self):
        """Obtiene el GeoDataFrame de la fuente seleccionada."""
        # Priorizar CSV cargado directamente
        if self.gdf is not None:
            return self.gdf

        # Desde capa QGIS
        layer_id = self.cmb_capa.currentData()
        if not layer_id:
            raise ValueError("Seleccioná una capa de puntos o cargá un CSV.")

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer:
            raise ValueError("La capa seleccionada no está disponible.")

        import geopandas as gpd
        import pandas as pd

        fields = [f.name() for f in layer.fields()]
        rows = []
        for feat in layer.getFeatures():
            row = dict(zip(fields, feat.attributes()))
            row["lon"] = feat.geometry().asPoint().x()
            row["lat"] = feat.geometry().asPoint().y()
            rows.append(row)

        df = pd.DataFrame(rows)
        # Normalizar fecha y tipo
        for c in ["fecha_hora", "fecha_hech", "fecha"]:
            if c in df.columns:
                df["fecha_hora"] = pd.to_datetime(df[c], infer_datetime_format=True, dayfirst=False)
                break
        for c in ["prevenible", "tipo_delito", "delito"]:
            if c in df.columns and "tipo_delito" not in df.columns:
                df["tipo_delito"] = df[c]; break

        gdf = gpd.GeoDataFrame(
            df,
            geometry=gpd.points_from_xy(df["lon"], df["lat"]),
            crs="EPSG:4326"
        )
        self.gdf = gdf
        self._poblar_tipos()
        return gdf

    def _run_analisis(self):
        try:
            gdf = self._get_gdf()
        except Exception as e:
            QMessageBox.warning(self, "Sin datos", str(e))
            return

        # Filtrar por tipo si corresponde
        tipo = self.cmb_tipo.currentText()
        if not tipo.startswith("Todos") and "tipo_delito" in gdf.columns:
            gdf = gdf[gdf["tipo_delito"] == tipo].copy()

        if len(gdf) < 3:
            QMessageBox.warning(self, "Datos insuficientes",
                                f"Se necesitan al menos 3 sitios de crimen.\n"
                                f"Con el filtro actual hay {len(gdf)} puntos.")
            return

        B    = self.spin_B.value()
        f    = self.spin_f.value()
        g    = self.spin_g.value()
        k    = self.spin_k.value()
        paso = self.spin_paso.value()

        self._set_status("Calculando superficie de probabilidad CGT...")
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self._gdf_activo = gdf

        from ..modules.rossmo_engine import pipeline_rossmo, interpretar_resultado
        from ..modules.layer_builder import generar_todas_las_capas

        def _run():
            res = pipeline_rossmo(gdf, B=B, f=f, g=g, k=k, paso=paso)
            capas = generar_todas_las_capas(res, gdf, res["metricas"])
            interp = interpretar_resultado(res["metricas"])
            return res, interp, capas

        self._worker = RossmoWorker(_run)
        self._worker.finished.connect(self._on_analisis_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_analisis_done(self, result):
        self.progress.setVisible(False)
        self.resultado, interp, capas = result
        self.metricas = self.resultado["metricas"]

        self.txt_resultado.setPlainText(interp)
        self.tabs.setCurrentIndex(1)
        self._set_status(
            f"Análisis completado. Anchor estimado: "
            f"Lat {self.metricas['anchor_lat']}, "
            f"Lon {self.metricas['anchor_lon']}"
        )

        if MATPLOTLIB_OK:
            self._plot_perfil()

    def _plot_perfil(self):
        """Perfil de probabilidad en el corte Y del anchor point."""
        if not self.resultado:
            return
        pm   = self.resultado["prob_matrix"]
        gx   = self.resultado["grid_x"]
        met  = self.metricas

        # Fila del anchor
        paso_y = float(self.resultado["grid_y"][1] - self.resultado["grid_y"][0])
        iy = int(np.clip(
            round((met["anchor_y_m"] - self.resultado["grid_y"][0]) / paso_y),
            0, pm.shape[0] - 1
        ))
        perfil = pm[iy, :]

        self.fig_r.clear()
        ax = self.fig_r.add_subplot(111)

        # Convertir gx a km relativo al centro
        xc = met["anchor_x_m"]
        gx_km = (gx - xc) / 1000.0

        ax.plot(gx_km, perfil, color="#CC0000", linewidth=1.5)
        ax.axvline(0, color="#FF4500", linewidth=1.0, linestyle="--",
                   label="Anchor estimado")
        ax.fill_between(gx_km, perfil, alpha=0.2, color="#CC0000")
        ax.set_xlabel("Distancia al anchor (km)")
        ax.set_ylabel("Probabilidad (%)")
        ax.set_title(f"Perfil CGT — B={met['B']:.0f}m  f={met['f']}  g={met['g']}")
        ax.legend(fontsize=8)
        self.fig_r.tight_layout()
        self.canvas_r.draw()

    def _calcular_con_anchor_real(self):
        """Recalcula el CGT Hit Score usando el anchor real ingresado."""
        if self.resultado is None:
            QMessageBox.warning(self, "Sin análisis",
                                "Ejecutá el análisis primero.")
            return

        try:
            lat = float(self.edit_lat_real.text().replace(",", "."))
            lon = float(self.edit_lon_real.text().replace(",", "."))
        except ValueError:
            QMessageBox.warning(self, "Error",
                                "Ingresá latitud y longitud válidas.")
            return

        from ..modules.rossmo_engine import (
            calcular_cgt_hit_score, preparar_crimen_coords,
            interpretar_resultado
        )
        from ..modules.layer_builder import crear_capa_anchor_real
        from pyproj import Transformer

        t = Transformer.from_crs("EPSG:4326", "EPSG:5345", always_xy=True)
        ax, ay = t.transform(lon, lat)

        cc  = self.resultado["crimen_coords"]
        pm  = self.resultado["prob_matrix"]
        gx  = self.resultado["grid_x"]
        gy  = self.resultado["grid_y"]
        met = self.metricas.copy()

        met_real = calcular_cgt_hit_score(cc, pm, gx, gy, anchor_real=(ax, ay))
        met_real.update({k: v for k, v in met.items()
                         if k not in met_real})

        # Agregar capa del anchor real al mapa
        crear_capa_anchor_real(lon, lat)

        texto = interpretar_resultado(met_real)
        self.txt_evaluacion.setPlainText(texto)
        self._set_status(
            f"CGT Hit Score con anchor real: {met_real['cgt_hit_score_pct']}%"
        )

        if MATPLOTLIB_OK:
            self._plot_comparacion(met_real)

    def _plot_comparacion(self, met_real):
        """Gráfico de barras comparando área de caza vs búsqueda."""
        self.fig_eval.clear()
        ax = self.fig_eval.add_subplot(111)
        areas  = [met_real["area_caza_km2"], met_real["area_busqueda_km2"]]
        labels = ["Área de caza", "Área de búsqueda\n(CGT)"]
        colores = ["#378ADD", "#CC0000"]
        bars = ax.bar(labels, areas, color=colores, alpha=0.85, width=0.4)
        for bar, val in zip(bars, areas):
            ax.text(bar.get_x() + bar.get_width()/2,
                    bar.get_height() + max(areas)*0.01,
                    f"{val:.1f} km²",
                    ha="center", va="bottom", fontsize=9)
        ax.set_ylabel("km²")
        ax.set_title(
            f"CGT Hit Score: {met_real['cgt_hit_score_pct']}% | "
            f"Dist. al anchor: {met_real.get('distancia_al_max_m', '?')} m"
        )
        self.fig_eval.tight_layout()
        self.canvas_eval.draw()

    def _exportar_informe(self):
        if not self.metricas:
            QMessageBox.warning(self, "Sin resultado",
                                "Ejecutá el análisis primero.")
            return
        fp, _ = QFileDialog.getSaveFileName(
            self, "Guardar informe", "rossmo_cba_informe.txt",
            "Archivos de texto (*.txt)"
        )
        if not fp:
            return

        from ..modules.rossmo_engine import interpretar_resultado
        from datetime import datetime

        texto = (
            "=" * 60 + "\n"
            "ROSSMO CBA — INFORME DE PERFILAMIENTO GEOGRÁFICO\n"
            f"Generado: {datetime.today().strftime('%d/%m/%Y %H:%M')}\n"
            "Uso interno. Confidencial.\n"
            "=" * 60 + "\n\n"
        ) + interpretar_resultado(self.metricas)

        with open(fp, "w", encoding="utf-8") as f_out:
            f_out.write(texto)
        QMessageBox.information(self, "Exportado", f"Guardado en:\n{fp}")

    def _set_status(self, msg):
        self.status.setText(msg)

    def _on_error(self, msg):
        self.progress.setVisible(False)
        self._set_status("Error.")
        QMessageBox.critical(self, "Error", msg)
        QgsMessageLog.logMessage(f"[RossmoCBA] ERROR: {msg}",
                                 "RossmoCBA", Qgis.Critical)
