# -*- coding: utf-8 -*-
"""
Crime Analyst CBA — Plugin QGIS
Cátedra Mapeo Delictivo, UNVM
"""

def classFactory(iface):
    from .main_plugin import CrimeAnalystCBA
    return CrimeAnalystCBA(iface)
