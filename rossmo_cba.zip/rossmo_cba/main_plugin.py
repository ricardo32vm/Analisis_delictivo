# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon


class RossmoCBA:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "Rossmo CBA"
        self.toolbar = self.iface.addToolBar("Rossmo CBA")
        self.toolbar.setObjectName("RossmoCBA")
        self.first_start = True

    def add_action(self, icon_path, text, callback, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        self.toolbar.addAction(action)
        self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "resources", "icon.svg")
        self.add_action(icon_path, "Abrir Rossmo CBA",
                        callback=self.run,
                        parent=self.iface.mainWindow())

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        from .ui.dialog_main import RossmoDialog
        if self.first_start:
            self.first_start = False
            self.dlg = RossmoDialog(iface=self.iface)
        self.dlg.show()
        self.dlg.exec_()
