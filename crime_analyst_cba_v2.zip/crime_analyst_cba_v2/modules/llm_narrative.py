# -*- coding: utf-8 -*-
"""
modules/llm_narrative.py

Genera narrativa táctica policial en español rioplatense
usando Ollama con Llama 3.2 corriendo localmente.

Comunicación con Ollama vía API REST (http://localhost:11434)
en lugar de subprocess, para mayor robustez y control de errores.
"""

import json
import urllib.request
import urllib.error
from datetime import datetime
from qgis.core import QgsMessageLog, Qgis


OLLAMA_URL  = "http://localhost:11434/api/generate"
OLLAMA_LIST = "http://localhost:11434/api/tags"
DEFAULT_MODEL = "llama3.2"

# Temperatura baja para respuestas más deterministas y profesionales
TEMPERATURE = 0.3
MAX_TOKENS  = 1200


SYSTEM_PROMPT = """Sos un analista criminal experto de la Policía de la Provincia de Córdoba, Argentina.
Tu función es interpretar estadísticas y patrones delictivos para generar informes tácticos concisos y precisos.

Usá siempre:
- Lenguaje policial institucional argentino (hechos ilícitos, modalidades delictivas, zona de influencia, 
  franja horaria, pico de actividad delictiva, zona de riesgo elevado, patrullaje preventivo, etc.)
- Terminología de la organización policial de Córdoba (distritos, seccionales, División, Departamento)
- Formato de informe operativo: párrafos cortos, datos precisos, recomendaciones concretas
- Nunca uses lenguaje informal ni emojis
- Las cantidades siempre en números (nunca "muchos" sino "47 hechos")
- Al final siempre incluí una sección "RECOMENDACIONES OPERATIVAS" con 3 a 5 puntos concretos
"""


def _ollama_request(prompt: str,
                    model: str = DEFAULT_MODEL,
                    stream: bool = False) -> str:
    """
    Envía un prompt a Ollama vía HTTP y retorna la respuesta completa.
    """
    payload = json.dumps({
        "model":  model,
        "prompt": prompt,
        "system": SYSTEM_PROMPT,
        "stream": stream,
        "options": {
            "temperature": TEMPERATURE,
            "num_predict": MAX_TOKENS,
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        OLLAMA_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            raw = response.read().decode("utf-8")

        # Ollama stream=False devuelve un único JSON
        data = json.loads(raw)
        return data.get("response", "").strip()

    except urllib.error.URLError as e:
        raise ConnectionError(
            f"No se pudo conectar con Ollama en {OLLAMA_URL}.\n"
            f"Verificá que Ollama esté corriendo: ollama serve\n"
            f"Error: {e.reason}"
        )
    except json.JSONDecodeError:
        raise RuntimeError(
            f"Respuesta inesperada de Ollama. Verificá que el modelo "
            f"'{model}' esté descargado: ollama pull {model}"
        )


def check_ollama_available(model: str = DEFAULT_MODEL) -> tuple:
    """
    Verifica que Ollama esté corriendo y el modelo esté disponible.
    Retorna (disponible: bool, mensaje: str).
    """
    try:
        req = urllib.request.Request(OLLAMA_LIST, method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        modelos = [m["name"].split(":")[0] for m in data.get("models", [])]
        if model in modelos or any(model in m for m in modelos):
            return True, f"Ollama OK — modelo '{model}' disponible."
        else:
            return False, (
                f"Ollama está corriendo pero el modelo '{model}' no está descargado.\n"
                f"Ejecutá: ollama pull {model}\n"
                f"Modelos disponibles: {', '.join(modelos) or 'ninguno'}"
            )
    except Exception as e:
        return False, (
            f"Ollama no está corriendo o no se encuentra en {OLLAMA_LIST}.\n"
            f"Iniciá Ollama con: ollama serve\n"
            f"Luego descargá el modelo: ollama pull {model}\n"
            f"Error: {e}"
        )


def generar_informe_hotspots(hotspots: list,
                              kde_descripcion: str,
                              tipo_delito: str = None,
                              distrito: str = None,
                              model: str = DEFAULT_MODEL) -> str:
    """
    Genera narrativa táctica sobre los hotspots detectados.

    Parámetros:
      - hotspots: lista de dicts {'lat', 'lon', 'densidad'}
      - kde_descripcion: texto descriptivo del análisis KDE
      - tipo_delito: tipo filtrado (o None si es general)
      - distrito: distrito filtrado (o None)
    """
    fecha_hoy = datetime.today().strftime("%d/%m/%Y")
    tipo_str  = f"Tipo de hecho ilícito: {tipo_delito}" if tipo_delito else "Tipo: todos los hechos registrados"
    dist_str  = f"Distrito policial: {distrito}" if distrito else "Ámbito: toda la ciudad de Córdoba"

    hotspot_texto = "\n".join([
        f"  Hotspot {i+1}: latitud {h['lat']}, longitud {h['lon']} — densidad relativa: {h['densidad']:.0f}/100"
        for i, h in enumerate(hotspots)
    ])

    prompt = f"""Fecha del análisis: {fecha_hoy}
{tipo_str}
{dist_str}

DESCRIPCIÓN TÉCNICA DEL ANÁLISIS KDE:
{kde_descripcion}

ZONAS DE MAYOR CONCENTRACIÓN DELICTIVA (hotspots):
{hotspot_texto}

Redactá un informe táctico operativo sobre los hotspots detectados.
El informe debe incluir:
1. Síntesis de la distribución espacial del delito
2. Análisis de las zonas críticas identificadas
3. Patrones geográficos relevantes
4. RECOMENDACIONES OPERATIVAS (3 a 5 puntos)
"""
    return _ollama_request(prompt, model)


def generar_informe_temporal(resumen_temporal: str,
                              prediccion_descripcion: str,
                              tipo_delito: str = None,
                              horizon: str = "semana",
                              model: str = DEFAULT_MODEL) -> str:
    """
    Genera narrativa táctica sobre tendencias temporales y predicción.
    """
    fecha_hoy = datetime.today().strftime("%d/%m/%Y")
    tipo_str  = f"Tipo de hecho ilícito: {tipo_delito}" if tipo_delito else "Tipo: todos los hechos registrados"
    horizon_str = "la próxima semana" if horizon == "semana" else "el próximo mes"

    prompt = f"""Fecha del análisis: {fecha_hoy}
{tipo_str}

ESTADÍSTICAS TEMPORALES HISTÓRICAS:
{resumen_temporal}

PROYECCIÓN PREDICTIVA PARA {horizon_str.upper()}:
{prediccion_descripcion}

Redactá un informe de análisis criminal temporal para elevar a la jefatura operativa.
El informe debe incluir:
1. Tendencias históricas observadas
2. Patrones de estacionalidad y distribución horaria
3. Proyección táctica para {horizon_str}
4. RECOMENDACIONES OPERATIVAS (3 a 5 puntos concretos de despliegue)
"""
    return _ollama_request(prompt, model)


def generar_informe_completo(hotspots: list,
                              kde_descripcion: str,
                              resumen_temporal: str,
                              prediccion_descripcion: str,
                              tipo_delito: str = None,
                              distrito: str = None,
                              horizon: str = "semana",
                              model: str = DEFAULT_MODEL) -> str:
    """
    Genera un informe completo unificando análisis espacial y temporal.
    """
    fecha_hoy = datetime.today().strftime("%d/%m/%Y")
    tipo_str  = f"Tipo de hecho ilícito: {tipo_delito}" if tipo_delito else "Tipo: todos los hechos registrados"
    dist_str  = f"Distrito policial: {distrito}" if distrito else "Ámbito: ciudad de Córdoba"
    horizon_str = "la próxima semana" if horizon == "semana" else "el próximo mes"

    hotspot_texto = "\n".join([
        f"  {i+1}. Lat {h['lat']}, Lon {h['lon']} — densidad {h['densidad']:.0f}/100"
        for i, h in enumerate(hotspots)
    ])

    prompt = f"""INFORME DE ANÁLISIS CRIMINAL — SISTEMA CRIME ANALYST CBA
Fecha: {fecha_hoy}
{tipo_str}
{dist_str}

=== ANÁLISIS ESPACIAL ===
{kde_descripcion}

Principales hotspots detectados:
{hotspot_texto}

=== ANÁLISIS TEMPORAL ===
{resumen_temporal}

=== PROYECCIÓN PREDICTIVA PARA {horizon_str.upper()} ===
{prediccion_descripcion}

Redactá el INFORME CRIMINAL INTEGRAL para elevar a la conducción policial.
Estructura:
1. RESUMEN EJECUTIVO (2-3 oraciones)
2. ANÁLISIS ESPACIAL DE LA CRIMINALIDAD
3. ANÁLISIS TEMPORAL Y ESTACIONAL
4. PROYECCIÓN DE RIESGO
5. RECOMENDACIONES OPERATIVAS (mínimo 4 puntos con recursos y horarios específicos)

Usá lenguaje policial institucional de la Provincia de Córdoba.
"""
    return _ollama_request(prompt, model)


def exportar_informe_txt(texto: str, output_path: str) -> str:
    """
    Guarda el informe narrativo en un archivo .txt.
    """
    fecha_str = datetime.today().strftime("%Y%m%d_%H%M")
    if not output_path.endswith(".txt"):
        output_path = f"{output_path}_{fecha_str}.txt"

    header = (
        "=" * 60 + "\n"
        "CRIME ANALYST CBA — INFORME DE ANÁLISIS CRIMINAL\n"
        f"Generado: {datetime.today().strftime('%d/%m/%Y %H:%M')}\n"
        "Sistema: Ollama / Llama 3.2 — Uso interno. Confidencial.\n"
        "=" * 60 + "\n\n"
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(header + texto)

    return output_path
