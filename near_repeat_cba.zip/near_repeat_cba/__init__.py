# -*- coding: utf-8 -*-
def classFactory(iface):
    from .main_plugin import NearRepeatCBA
    return NearRepeatCBA(iface)
