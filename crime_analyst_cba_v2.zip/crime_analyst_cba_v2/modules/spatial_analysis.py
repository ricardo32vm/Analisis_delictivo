# -*- coding: utf-8 -*-
"""
modules/spatial_analysis.py

Análisis espacial:
  - Kernel Density Estimation (KDE) para hotspots
  - Predicción de zonas de riesgo para próxima semana / mes
  - Exportación como raster GeoTIFF para cargar en QGIS

Dependencias: geopandas, numpy, scipy, rasterio, sklearn
"""

import numpy as np
import geopandas as gpd
import pandas as pd
from scipy.stats import gaussian_kde
from datetime import datetime, timedelta
import os
import tempfile

try:
    import rasterio
    from rasterio.transform import from_bounds
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False

from qgis.core import (
    QgsRasterLayer, QgsVectorLayer, QgsProject,
    QgsMessageLog, Qgis, QgsCoordinateReferenceSystem
)


# Resolución del raster KDE (celdas)
DEFAULT_GRID_SIZE = 500   # 500x500 puntos sobre el bounding box


def compute_kde(gdf: gpd.GeoDataFrame,
                tipo_delito: str = None,
                distrito: str = None,
                anio_desde: int = None,
                anio_hasta: int = None,
                grid_size: int = DEFAULT_GRID_SIZE,
                bandwidth: float = None) -> dict:
    """
    Calcula el KDE sobre los puntos del GeoDataFrame.

    Parámetros:
      - tipo_delito: filtrar por tipo (None = todos)
      - distrito: filtrar por distrito policial
      - anio_desde / anio_hasta: filtro temporal
      - grid_size: resolución del raster
      - bandwidth: ancho de banda KDE (None = Scott's rule automático)

    Retorna dict con:
      - 'density': array 2D numpy
      - 'extent': (xmin, xmax, ymin, ymax)
      - 'n_puntos': cantidad de puntos usados
    """
    data = gdf.copy()

    # Aplicar filtros
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]
    if distrito and "distrito" in data.columns:
        data = data[data["distrito"] == distrito]
    if anio_desde and "anio" in data.columns:
        data = data[data["anio"] >= anio_desde]
    if anio_hasta and "anio" in data.columns:
        data = data[data["anio"] <= anio_hasta]

    if len(data) < 5:
        raise ValueError(
            f"Insuficientes puntos para KDE ({len(data)}). "
            "Ampliá los filtros de búsqueda."
        )

    x = data.geometry.x.values
    y = data.geometry.y.values

    xmin, xmax = x.min(), x.max()
    ymin, ymax = y.min(), y.max()

    # Agregar margen del 5%
    dx = (xmax - xmin) * 0.05
    dy = (ymax - ymin) * 0.05
    xmin -= dx; xmax += dx
    ymin -= dy; ymax += dy

    # Grilla de evaluación
    xi, yi = np.mgrid[xmin:xmax:complex(grid_size),
                      ymin:ymax:complex(grid_size)]
    positions = np.vstack([xi.ravel(), yi.ravel()])
    values    = np.vstack([x, y])

    # KDE con scipy
    kde = gaussian_kde(values, bw_method=bandwidth)
    density = kde(positions).reshape(grid_size, grid_size)

    # Normalizar 0-100
    density = (density / density.max()) * 100

    return {
        "density":  density,
        "extent":   (xmin, xmax, ymin, ymax),
        "n_puntos": len(data),
        "xi": xi, "yi": yi,
    }


def kde_to_raster(kde_result: dict, output_path: str = None) -> str:
    """
    Guarda el array de densidad KDE como GeoTIFF en EPSG:4326.
    Retorna la ruta al archivo.
    """
    if not RASTERIO_OK:
        raise ImportError(
            "rasterio no está instalado. "
            "Ejecutá: pip install rasterio --break-system-packages"
        )

    if output_path is None:
        tmp = tempfile.mktemp(suffix="_kde.tif")
        output_path = tmp

    density = kde_result["density"]
    xmin, xmax, ymin, ymax = kde_result["extent"]
    grid_size = density.shape[0]

    transform = from_bounds(xmin, ymin, xmax, ymax,
                            grid_size, grid_size)

    with rasterio.open(
        output_path, "w",
        driver="GTiff",
        height=grid_size,
        width=grid_size,
        count=1,
        dtype=density.dtype,
        crs="EPSG:4326",
        transform=transform,
    ) as dst:
        # rasterio espera el array transpuesto (cols, rows) → (rows, cols)
        dst.write(density.T[::-1], 1)

    return output_path


def add_kde_to_qgis(kde_result: dict, layer_name: str = "KDE Delitos") -> QgsRasterLayer:
    """
    Genera el GeoTIFF KDE y lo agrega al proyecto QGIS con rampa de color.
    Retorna el QgsRasterLayer creado.
    """
    tif_path = kde_to_raster(kde_result)

    layer = QgsRasterLayer(tif_path, layer_name)
    if not layer.isValid():
        raise RuntimeError(f"No se pudo cargar el raster KDE: {tif_path}")

    # Aplicar rampa de color (amarillo → rojo)
    _apply_heatmap_style(layer)

    QgsProject.instance().addMapLayer(layer)
    QgsMessageLog.logMessage(
        f"[CrimeAnalyst] Capa KDE '{layer_name}' agregada al mapa.",
        "CrimeAnalystCBA", Qgis.Info
    )
    return layer


def _apply_heatmap_style(layer: QgsRasterLayer):
    """Aplica rampa de color tipo heatmap al raster KDE."""
    from qgis.core import (
        QgsRasterShader, QgsColorRampShader,
        QgsSingleBandPseudoColorRenderer
    )
    from qgis.PyQt.QtGui import QColor

    shader = QgsRasterShader()
    color_ramp = QgsColorRampShader()
    color_ramp.setColorRampType(QgsColorRampShader.Interpolated)

    color_ramp.setColorRampItemList([
        QgsColorRampShader.ColorRampItem(0,   QColor(0,   0, 255, 0),   "Sin actividad"),
        QgsColorRampShader.ColorRampItem(20,  QColor(0, 200, 255, 80),  "Baja"),
        QgsColorRampShader.ColorRampItem(40,  QColor(0, 255,   0, 120), "Moderada"),
        QgsColorRampShader.ColorRampItem(60,  QColor(255, 255, 0, 160), "Alta"),
        QgsColorRampShader.ColorRampItem(80,  QColor(255, 128, 0, 200), "Muy alta"),
        QgsColorRampShader.ColorRampItem(100, QColor(255,   0, 0, 240), "Crítica"),
    ])

    shader.setRasterShaderFunction(color_ramp)
    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


# ---------------------------------------------------------------------------
# PREDICCIÓN DE ZONAS DE RIESGO
# ---------------------------------------------------------------------------

def predict_risk_zones(gdf: gpd.GeoDataFrame,
                       horizon: str = "semana",
                       tipo_delito: str = None) -> dict:
    """
    Predice zonas de riesgo para la próxima semana o mes.

    Metodología:
      1. Calcula KDE base sobre todo el histórico.
      2. Extrae el patrón estacional del período equivalente
         (misma semana del año / mismo mes) en años anteriores.
      3. Pondera el KDE histórico con el factor estacional.

    Parámetros:
      - horizon: 'semana' o 'mes'
      - tipo_delito: filtrar por tipo (None = todos)

    Retorna dict con:
      - 'kde_prediccion': resultado KDE ponderado
      - 'factor_estacional': float (multiplicador aplicado)
      - 'descripcion': texto descriptivo
      - 'periodo_ref': texto del período de referencia histórica
    """
    hoy = datetime.today()
    data = gdf.copy()

    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]

    if "fecha_hora" not in data.columns or data["fecha_hora"].isna().all():
        # Sin fechas, predicción = KDE histórico plano
        kde_base = compute_kde(data)
        return {
            "kde_prediccion": kde_base,
            "factor_estacional": 1.0,
            "descripcion": "Predicción basada en distribución histórica (sin datos temporales).",
            "periodo_ref": "Todo el período"
        }

    # ---- Factor estacional ----
    if horizon == "semana":
        # Semana ISO del año próxima
        semana_target = (hoy + timedelta(weeks=1)).isocalendar()[1]
        mes_target    = (hoy + timedelta(weeks=1)).month

        # Contar hechos en esa semana ISO en años anteriores
        mask_hist = data["fecha_hora"].dt.isocalendar().week == semana_target
        n_hist = mask_hist.sum()

        # Promedio anual de esa semana
        n_anios = max(1, data["anio"].nunique())
        promedio_semana = n_hist / n_anios

        # Promedio general por semana
        total_semanas = max(1, len(data) / 52)
        factor = promedio_semana / total_semanas if total_semanas > 0 else 1.0
        factor = min(max(factor, 0.5), 3.0)  # clamp razonable

        periodo_ref = f"Semana {semana_target} (promedio histórico: {promedio_semana:.1f} hechos)"

    else:  # mes
        mes_target = (hoy.replace(day=1) + timedelta(days=32)).replace(day=1).month
        mask_hist = data["fecha_hora"].dt.month == mes_target
        n_hist = mask_hist.sum()
        n_anios = max(1, data["anio"].nunique())
        promedio_mes = n_hist / n_anios

        total_mes_prom = len(data) / 12
        factor = promedio_mes / total_mes_prom if total_mes_prom > 0 else 1.0
        factor = min(max(factor, 0.5), 3.0)

        meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
                 "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]
        periodo_ref = f"{meses[mes_target-1]} (promedio histórico: {promedio_mes:.1f} hechos)"

    # ---- KDE base sobre datos recientes (últimos 2 años) ----
    anio_reciente = hoy.year - 2
    data_reciente = data[data["anio"] >= anio_reciente] if "anio" in data.columns else data
    if len(data_reciente) < 10:
        data_reciente = data  # fallback al total

    kde_base = compute_kde(data_reciente)

    # ---- Ponderar densidad por factor estacional ----
    kde_pred = kde_base.copy()
    kde_pred["density"] = np.clip(kde_base["density"] * factor, 0, 100)

    tipo_str = f" — {tipo_delito}" if tipo_delito else ""
    descripcion = (
        f"Predicción para la próxima {horizon}{tipo_str}.\n"
        f"Factor estacional aplicado: {factor:.2f}x\n"
        f"Referencia histórica: {periodo_ref}"
    )

    return {
        "kde_prediccion": kde_pred,
        "factor_estacional": factor,
        "descripcion": descripcion,
        "periodo_ref": periodo_ref,
    }


def get_top_hotspots(kde_result: dict, n: int = 5) -> list:
    """
    Extrae las N coordenadas con mayor densidad del KDE.
    Retorna lista de dicts con lat, lon, densidad.
    """
    density = kde_result["density"]
    xi = kde_result["xi"]
    yi = kde_result["yi"]

    flat_idx = np.argsort(density.ravel())[::-1][:n * 10]
    hotspots = []
    seen = set()

    for idx in flat_idx:
        row, col = divmod(idx, density.shape[1])
        lon = xi[row, col]
        lat = yi[row, col]
        # Evitar duplicados cercanos (radio ~0.005°)
        key = (round(lon, 2), round(lat, 2))
        if key not in seen:
            seen.add(key)
            hotspots.append({
                "lon": round(lon, 5),
                "lat": round(lat, 5),
                "densidad": round(float(density[row, col]), 1),
            })
        if len(hotspots) >= n:
            break

    return hotspots
