# -*- coding: utf-8 -*-
"""
main_plugin.py
Registro del plugin en la interfaz de QGIS.
"""

import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QTranslator, QCoreApplication


class CrimeAnalystCBA:
    """Clase principal del plugin."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "Crime Analyst CBA"
        self.toolbar = self.iface.addToolBar("Crime Analyst CBA")
        self.toolbar.setObjectName("CrimeAnalystCBA")
        self.first_start = None

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True,
                   status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "resources", "icon.png")
        self.add_action(
            icon_path,
            text="Abrir Crime Analyst CBA",
            callback=self.run,
            parent=self.iface.mainWindow()
        )
        self.first_start = True

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu("Crime Analyst CBA", action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        from .ui.dialog_main import CrimeAnalystDialog
        if self.first_start:
            self.first_start = False
            self.dlg = CrimeAnalystDialog(iface=self.iface)
        self.dlg.show()
        result = self.dlg.exec_()
        if result:
            pass
