# -*- coding: utf-8 -*-
"""
modules/knox_test.py

Implementación del Knox test para análisis de victimización near repeat.
Python 3 puro — sin dependencias externas más allá de NumPy y SciPy.

Referencia:
  Knox, E.G. (1964). The detection of space-time interactions.
  Journal of the Royal Statistical Society, Series C, 13(1), 25–29.

  Sherman, L.W. et al. (1989). Hot spots of predatory crime.
  Criminology, 27(1), 27–56.

El test identifica pares de eventos que son simultáneamente:
  - cercanos en el espacio (distancia ≤ umbral espacial)
  - cercanos en el tiempo  (diferencia temporal ≤ umbral temporal)

Si la cantidad observada de esos pares supera significativamente
lo esperado bajo aleatoriedad (estimado por Monte Carlo), existe
un patrón de near repeat estadísticamente significativo.
"""

import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.spatial.distance import cdist
from datetime import datetime
from qgis.core import QgsMessageLog, Qgis


# ---------------------------------------------------------------------------
# Carga y preparación de datos
# ---------------------------------------------------------------------------

def preparar_datos(gdf: gpd.GeoDataFrame,
                   tipo_delito: str = None,
                   distrito: str = None,
                   fecha_desde: str = None,
                   fecha_hasta: str = None) -> pd.DataFrame:
    """
    Prepara el GeoDataFrame para el Knox test.
    Retorna DataFrame con columnas: id, x, y, t (timestamp en días), lat, lon,
    tipo_delito, distrito, fecha_hora.
    """
    data = gdf.copy()

    # Filtros opcionales
    if tipo_delito and "tipo_delito" in data.columns:
        data = data[data["tipo_delito"] == tipo_delito]
    if distrito and "distrito" in data.columns:
        data = data[data["distrito"] == distrito]
    if fecha_desde and "fecha_hora" in data.columns:
        data = data[data["fecha_hora"] >= pd.to_datetime(fecha_desde)]
    if fecha_hasta and "fecha_hora" in data.columns:
        data = data[data["fecha_hora"] <= pd.to_datetime(fecha_hasta)]

    if len(data) < 10:
        raise ValueError(
            f"Insuficientes eventos para el análisis ({len(data)}). "
            "Ampliá los filtros de búsqueda."
        )

    # Proyectar a metros para distancias reales
    # POSGAR 2007 / Argentina faja 3 — válido para Córdoba ciudad
    data_proj = data.to_crs("EPSG:5345")

    df = pd.DataFrame({
        "id":          range(len(data_proj)),
        "x":           data_proj.geometry.x.values,
        "y":           data_proj.geometry.y.values,
        "lon":         data.geometry.x.values,
        "lat":         data.geometry.y.values,
        "fecha_hora":  data["fecha_hora"].values if "fecha_hora" in data.columns else None,
        "tipo_delito": data["tipo_delito"].values if "tipo_delito" in data.columns else "desconocido",
        "distrito":    data["distrito"].values if "distrito" in data.columns else "",
    })

    # Tiempo en días desde el primer evento
    if "fecha_hora" in data.columns and data["fecha_hora"].notna().any():
        t0 = pd.to_datetime(df["fecha_hora"]).min()
        df["t_dias"] = (pd.to_datetime(df["fecha_hora"]) - t0).dt.total_seconds() / 86400.0
    else:
        raise ValueError("El dataset no tiene columna de fecha/hora. El Knox test requiere fechas.")

    df = df.dropna(subset=["x", "y", "t_dias"])
    df = df.reset_index(drop=True)
    df["id"] = df.index

    QgsMessageLog.logMessage(
        f"[NearRepeat] Datos preparados: {len(df)} eventos.",
        "NearRepeatCBA", Qgis.Info
    )
    return df


# ---------------------------------------------------------------------------
# Knox test
# ---------------------------------------------------------------------------

def calcular_pares_knox(df: pd.DataFrame,
                         dist_umbral: float,
                         tiempo_umbral: float) -> tuple:
    """
    Calcula la matriz de pares near repeat para un umbral espacial y temporal.

    Parámetros:
      - df: DataFrame con columnas x, y, t_dias
      - dist_umbral: distancia máxima en metros
      - tiempo_umbral: diferencia temporal máxima en días

    Retorna:
      - n_obs: cantidad observada de pares near repeat
      - mask_espacio: matriz booleana de pares espacialmente cercanos
      - mask_tiempo: matriz booleana de pares temporalmente cercanos
      - mask_nr: matriz booleana de pares near repeat (ambas condiciones)
    """
    coords = df[["x", "y"]].values
    tiempos = df["t_dias"].values
    n = len(df)

    # Matriz de distancias espaciales (metros)
    dist_mat = cdist(coords, coords, metric="euclidean")

    # Matriz de diferencias temporales (días)
    time_mat = np.abs(tiempos[:, None] - tiempos[None, :])

    # Máscara triangular superior (evitar doble conteo y diagonal)
    tri_sup = np.triu(np.ones((n, n), dtype=bool), k=1)

    # Pares near repeat: dentro del umbral espacial Y temporal
    mask_espacio = (dist_mat <= dist_umbral) & tri_sup
    mask_tiempo  = (time_mat <= tiempo_umbral) & tri_sup
    mask_nr      = mask_espacio & mask_tiempo

    n_obs = int(mask_nr.sum())

    return n_obs, mask_espacio, mask_tiempo, mask_nr


def knox_montecarlo(df: pd.DataFrame,
                    dist_umbral: float,
                    tiempo_umbral: float,
                    n_sim: int = 999,
                    seed: int = 42) -> dict:
    """
    Knox test con Monte Carlo para estimar el p-valor.

    Metodología:
      1. Calcula el número observado de pares near repeat (n_obs).
      2. Repite n_sim veces permutando aleatoriamente los tiempos
         manteniendo las coordenadas fijas.
      3. El p-valor es la proporción de simulaciones con n_sim >= n_obs.
      4. El Knox ratio = n_obs / media(n_sim).

    Retorna dict con:
      n_obs, n_sim_media, n_sim_std, p_valor, knox_ratio,
      mask_nr, mask_espacio, mask_tiempo, df
    """
    rng = np.random.default_rng(seed)

    n_obs, mask_espacio, mask_tiempo, mask_nr = calcular_pares_knox(
        df, dist_umbral, tiempo_umbral
    )

    coords = df[["x", "y"]].values
    tiempos = df["t_dias"].values
    n = len(df)
    tri_sup = np.triu(np.ones((n, n), dtype=bool), k=1)

    # Distancias espaciales precalculadas (no cambian en las permutaciones)
    dist_mat = cdist(coords, coords, metric="euclidean")
    mask_esp_pre = (dist_mat <= dist_umbral) & tri_sup

    sim_counts = np.zeros(n_sim, dtype=int)

    QgsMessageLog.logMessage(
        f"[NearRepeat] Iniciando Monte Carlo: {n_sim} simulaciones...",
        "NearRepeatCBA", Qgis.Info
    )

    for i in range(n_sim):
        t_perm = rng.permutation(tiempos)
        time_mat_perm = np.abs(t_perm[:, None] - t_perm[None, :])
        mask_t_perm = (time_mat_perm <= tiempo_umbral) & tri_sup
        sim_counts[i] = int((mask_esp_pre & mask_t_perm).sum())

    # p-valor: proporción de simulaciones >= observado
    p_valor = float((sim_counts >= n_obs).sum()) / n_sim

    # Knox ratio: observado / media simulada
    media_sim = float(sim_counts.mean())
    knox_ratio = (n_obs / media_sim) if media_sim > 0 else 0.0

    QgsMessageLog.logMessage(
        f"[NearRepeat] n_obs={n_obs}, media_sim={media_sim:.1f}, "
        f"p={p_valor:.4f}, Knox ratio={knox_ratio:.3f}",
        "NearRepeatCBA", Qgis.Info
    )

    return {
        "n_obs":       n_obs,
        "n_sim_media": media_sim,
        "n_sim_std":   float(sim_counts.std()),
        "p_valor":     p_valor,
        "knox_ratio":  knox_ratio,
        "mask_nr":     mask_nr,
        "mask_espacio": mask_espacio,
        "mask_tiempo":  mask_tiempo,
        "sim_counts":  sim_counts,
        "df":          df,
        "dist_umbral":  dist_umbral,
        "tiempo_umbral": tiempo_umbral,
    }


def knox_multibanda(df: pd.DataFrame,
                    bandas_dist: list,
                    bandas_tiempo: list,
                    n_sim: int = 999,
                    seed: int = 42) -> dict:
    """
    Knox test con múltiples bandas espaciales y temporales.
    Genera una matriz de resultados (p-valores y Knox ratios)
    equivalente a la salida del Near Repeat Calculator de Ratcliffe.

    Parámetros:
      - bandas_dist: lista de umbrales espaciales en metros
                     ej: [0, 200, 400, 600, 800, 1000]
      - bandas_tiempo: lista de umbrales temporales en días
                       ej: [0, 7, 14, 21, 28]

    Retorna dict con matrices de p-valores y Knox ratios.
    """
    rng = np.random.default_rng(seed)
    n = len(df)
    coords = df[["x", "y"]].values
    tiempos = df["t_dias"].values
    tri_sup = np.triu(np.ones((n, n), dtype=bool), k=1)

    # Precalcular matrices base (no cambian con permutaciones)
    dist_mat = cdist(coords, coords, metric="euclidean")
    time_mat = np.abs(tiempos[:, None] - tiempos[None, :])

    nd = len(bandas_dist) - 1
    nt = len(bandas_tiempo) - 1

    # Conteos observados por celda de la matriz
    obs_counts = np.zeros((nd, nt), dtype=int)
    for di in range(nd):
        for ti in range(nt):
            mask_d = (dist_mat > bandas_dist[di]) & (dist_mat <= bandas_dist[di+1]) & tri_sup
            mask_t = (time_mat > bandas_tiempo[ti]) & (time_mat <= bandas_tiempo[ti+1]) & tri_sup
            obs_counts[di, ti] = int((mask_d & mask_t).sum())

    # Monte Carlo
    sim_counts = np.zeros((n_sim, nd, nt), dtype=int)
    for s in range(n_sim):
        t_perm = rng.permutation(tiempos)
        time_mat_perm = np.abs(t_perm[:, None] - t_perm[None, :])
        for di in range(nd):
            for ti in range(nt):
                mask_d = (dist_mat > bandas_dist[di]) & (dist_mat <= bandas_dist[di+1]) & tri_sup
                mask_t = (time_mat_perm > bandas_tiempo[ti]) & (time_mat_perm <= bandas_tiempo[ti+1]) & tri_sup
                sim_counts[s, di, ti] = int((mask_d & mask_t).sum())

    # P-valores y Knox ratios por celda
    p_matrix     = np.zeros((nd, nt))
    ratio_matrix = np.zeros((nd, nt))
    for di in range(nd):
        for ti in range(nt):
            sim_col = sim_counts[:, di, ti]
            p_matrix[di, ti]     = float((sim_col >= obs_counts[di, ti]).sum()) / n_sim
            media = sim_col.mean()
            ratio_matrix[di, ti] = (obs_counts[di, ti] / media) if media > 0 else 0.0

    etiq_dist   = [f"{int(bandas_dist[i])}-{int(bandas_dist[i+1])}m" for i in range(nd)]
    etiq_tiempo = [f"{int(bandas_tiempo[i])}-{int(bandas_tiempo[i+1])}d" for i in range(nt)]

    return {
        "obs_counts":   obs_counts,
        "p_matrix":     p_matrix,
        "ratio_matrix": ratio_matrix,
        "etiq_dist":    etiq_dist,
        "etiq_tiempo":  etiq_tiempo,
        "bandas_dist":  bandas_dist,
        "bandas_tiempo": bandas_tiempo,
        "n_sim":        n_sim,
    }


# ---------------------------------------------------------------------------
# Clasificación de riesgo por punto
# ---------------------------------------------------------------------------

def calcular_riesgo_por_punto(resultado: dict) -> pd.DataFrame:
    """
    Asigna a cada evento un nivel de riesgo NR basado en cuántos
    pares near repeat tiene (como origen O como destino).

    Niveles:
      0 — Sin riesgo NR detectado
      1 — Riesgo bajo  (1 par NR)
      2 — Riesgo medio (2-3 pares NR)
      3 — Riesgo alto  (4+ pares NR)

    También identifica si el evento es:
      - "repetición exacta" (same repeat): mismo punto victimizado de nuevo
      - "near repeat": punto cercano victimizado
    """
    df      = resultado["df"]
    mask_nr = resultado["mask_nr"]
    n       = len(df)

    # Conteo de pares NR por punto (como origen o destino)
    conteo_nr = np.zeros(n, dtype=int)
    filas, cols = np.where(mask_nr)
    for f, c in zip(filas, cols):
        conteo_nr[f] += 1
        conteo_nr[c] += 1

    # Nivel de riesgo
    nivel = np.zeros(n, dtype=int)
    nivel[conteo_nr == 1] = 1
    nivel[(conteo_nr >= 2) & (conteo_nr <= 3)] = 2
    nivel[conteo_nr >= 4] = 3

    df = df.copy()
    df["conteo_nr"] = conteo_nr
    df["nivel_riesgo"] = nivel
    df["nivel_texto"] = pd.cut(
        nivel,
        bins=[-1, 0, 1, 3, 100],
        labels=["Sin riesgo NR", "Riesgo bajo", "Riesgo medio", "Riesgo alto"]
    )

    return df


def extraer_pares_nr(resultado: dict) -> pd.DataFrame:
    """
    Extrae todos los pares near repeat como DataFrame de líneas.
    Retorna DataFrame con: id_origen, id_destino, distancia_m,
    diff_dias, lon_orig, lat_orig, lon_dest, lat_dest.
    """
    df      = resultado["df"]
    mask_nr = resultado["mask_nr"]

    filas, cols = np.where(mask_nr)
    coords  = df[["x", "y"]].values
    tiempos = df["t_dias"].values

    pares = []
    for f, c in zip(filas, cols):
        dist = float(np.sqrt((coords[f,0]-coords[c,0])**2 + (coords[f,1]-coords[c,1])**2))
        pares.append({
            "id_origen":  int(df.iloc[f]["id"]),
            "id_destino": int(df.iloc[c]["id"]),
            "distancia_m": round(dist, 1),
            "diff_dias":   round(abs(tiempos[f] - tiempos[c]), 1),
            "lon_orig":   float(df.iloc[f]["lon"]),
            "lat_orig":   float(df.iloc[f]["lat"]),
            "lon_dest":   float(df.iloc[c]["lon"]),
            "lat_dest":   float(df.iloc[c]["lat"]),
            "tipo_orig":  str(df.iloc[f].get("tipo_delito", "")),
            "tipo_dest":  str(df.iloc[c].get("tipo_delito", "")),
        })

    return pd.DataFrame(pares)


def interpretar_resultado(resultado: dict) -> str:
    """
    Genera un texto de interpretación del Knox test para mostrar en el panel.
    """
    n_obs   = resultado["n_obs"]
    media   = resultado["n_sim_media"]
    std     = resultado["n_sim_std"]
    p       = resultado["p_valor"]
    ratio   = resultado["knox_ratio"]
    n_sim   = len(resultado["sim_counts"])
    dist_u  = resultado["dist_umbral"]
    tiempo_u = resultado["tiempo_umbral"]

    if p <= 0.01:
        sig = "MUY SIGNIFICATIVO (p ≤ 0.01) ✓✓"
    elif p <= 0.05:
        sig = "SIGNIFICATIVO (p ≤ 0.05) ✓"
    elif p <= 0.10:
        sig = "MARGINALMENTE SIGNIFICATIVO (p ≤ 0.10)"
    else:
        sig = "NO SIGNIFICATIVO (p > 0.10)"

    lineas = [
        "═" * 45,
        "  RESULTADO DEL KNOX TEST — NEAR REPEAT",
        "═" * 45,
        f"  Umbral espacial:    {dist_u:.0f} metros",
        f"  Umbral temporal:    {tiempo_u:.0f} días",
        f"  Simulaciones MC:    {n_sim}",
        "─" * 45,
        f"  Pares observados:   {n_obs}",
        f"  Media simulada:     {media:.1f}  (±{std:.1f})",
        f"  Knox ratio:         {ratio:.3f}",
        f"  p-valor:            {p:.4f}",
        f"  Significancia:      {sig}",
        "─" * 45,
    ]

    if p <= 0.05 and ratio > 1:
        lineas.append(
            f"  INTERPRETACIÓN: Existe un patrón near repeat\n"
            f"  estadísticamente significativo. Los eventos\n"
            f"  dentro de {dist_u:.0f}m y {tiempo_u:.0f} días presentan\n"
            f"  {ratio:.1f}x más co-ocurrencias que lo esperado\n"
            f"  por azar."
        )
    elif p > 0.05:
        lineas.append(
            "  INTERPRETACIÓN: No se detecta patrón near\n"
            "  repeat significativo con los umbrales\n"
            "  seleccionados. Probá ampliar distancia\n"
            "  o tiempo."
        )

    lineas.append("═" * 45)
    return "\n".join(lineas)
